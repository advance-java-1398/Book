public class Example16_2
{
   public static void main(String[] args) throws Exception
   {
     StringInverse myStr = new StringInverse();
     myStr.showStringStack();
   }
}
