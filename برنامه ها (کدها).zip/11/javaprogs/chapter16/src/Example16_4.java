public class Example16_4 
{
   public static void main(String[] args)
   {
      SearchTree t = new SearchTree();
      //insert 12 name in tree and print them
      t.insert("Reza");
      t.insert("Davood");
      t.insert("Ramin");
      t.insert("Javad");
      t.insert("Jalil");
      t.insert("Ramazan");
      t.insert("Darya");
      t.insert("Jelal");
      t.insert("Karim");
      t.insert("Amin");
      t.display();
   }
}
