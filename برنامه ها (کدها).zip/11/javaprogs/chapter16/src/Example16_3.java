public class Example16_3
{
  public static void main(String[] args)
  {
    Queue q = new Queue();
    String name;
    //Insert 4 names
    q.insert("Ali");
    q.insert("Mohammad");
    q.insert("Ahmad");
    q.insert("Reza");
    q.display();
  }
}
