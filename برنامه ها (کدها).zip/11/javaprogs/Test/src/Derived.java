
public class Derived  extends Base{
	private int y;

}
