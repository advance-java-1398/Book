import java.io.*;
import java.util.*;
public class Filetest
{
	public static void main(String[] args)
	{
		String fileName = "nameSt.dat";
		createFile(fileName);
		printFile(fileName);
	}
	//**************
	public static void createFile(String fileName)
	{
		Scanner console = new Scanner(System.in);
		try
		{
			PrintWriter outFile = new PrintWriter(fileName);
			String str;
			double grade;
			System.out.print("Enter a name : ");
			str = console.next();
			while(!str.trim().equals("stop"))
			{
				outFile.print(str + " ");
				System.out.print("Enter grade :");
				grade = console.nextDouble();
				//System.out.print(" kkkkk" + grade);
				outFile.print(grade);
				outFile.print(" ");
				System.out.print("Enter a name : ");
				str = console.next();
			}
			outFile.close();
		}
        catch(Exception e) 
        {
        	System.out.print(e.getMessage());
        }
	}//end of createFile
    //*****************
	public static void printFile(String fileName)
	{
		try
		{
			Scanner inFile = new Scanner(new FileReader(fileName));
			String str;
			double grade;
			System.out.print("\nRead from file : \n");
			str = inFile.next();
			while(str != null)
			{
				grade = inFile.nextDouble();
				System.out.print(str + " : ");
				System.out.println(grade);
				
				str = inFile.next();
			}
			inFile.close();
		}
		catch(Exception e)
		{
			if(e.getMessage() != null)
			{
				System.out.print(e.getMessage());
			}
		}
	}
}
