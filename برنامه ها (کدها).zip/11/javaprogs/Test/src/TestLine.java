import java.io.*;
import java.util.*;
public class TestLine
{
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) throws Exception
	{
     try
     {
		String fileName = "student.dat";
	   PrintWriter outFile  = new PrintWriter(fileName);
	  // BufferedWriter writer = new BufferedWriter(outFile);
	   String str;
	   System.out.print("Enter a name :");
	   str = in.nextLine();
	   while(!str.trim().equals("stop"))
	   {
	     outFile.write(str + "\n");
	     System.out.print("Enter a name :");
	     str = in.nextLine();
	   }
      int i = 0;
	   outFile.flush();
	   outFile.close();
	   Scanner inFile = new Scanner(new FileReader(fileName));
	 //  FileReader inFile = new FileReader(fileName);
	 //  BufferedReader reader = new BufferedReader(inFile);
	   str =  inFile.nextLine();
	   while(str != null)
	   {
	      System.out.println(str);
	      str =  inFile.nextLine();
	      i ++;
	   }
	   System.out.print(i);
	   inFile.close();
	 }
     catch(Exception e)
     {
    	 System.out.print("");
     }
	}
}
