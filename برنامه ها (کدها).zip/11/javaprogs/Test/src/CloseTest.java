import javax.swing.*;
public class CloseTest
{
	  public static void main(String[] args) throws Exception
	  {
	    CanClose frame = new CanClose("This is a test");
	    final int width = 300, height = 100;
	    frame.setSize(width, height);
	    frame.setVisible(true);
	    frame.setResizable(false);

	  }

}
