
public class TextComponentTest
{
   public static void main(String[] arg)
   {
	   TestComponentFrame t = new TestComponentFrame();
	   t.setVisible(true);
   }
}
