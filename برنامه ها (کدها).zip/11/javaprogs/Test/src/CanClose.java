import javax.swing.*;
import javax.swing.event.*;
import javax.swing.JOptionPane;                        //Line 1
import java.awt.event.*;
import java.awt.*;
public class CanClose extends JFrame implements WindowListener
{
   public CanClose(String s)
   {
	   super(s);
	   addWindowListener(this);
   }
   public void windowClosing(WindowEvent e)
   {
       String outputStr =  " YYYYYYYYYYYYYYYY";
	   JOptionPane.showMessageDialog(null, outputStr,
               "Circle",
        JOptionPane.INFORMATION_MESSAGE);   //Line 16

     System.exit(0);
   }
   Graphics g ;
   public void windowClosed(WindowEvent e){}
   public void windowDeiconified(WindowEvent e){}
   public void windowIconified(WindowEvent e){}
   public void windowOpened(WindowEvent e){}
   public void windowActivated(WindowEvent e){}
   public void windowDeactivated(WindowEvent e){}

}
