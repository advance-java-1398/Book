
public class Ctest {
	public static void main(String[] args)
	{
     Derived d = new Derived();
     System.out.print(d.getXx());
	}
}
