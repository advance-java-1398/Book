
public class Base {
  private int x;
  public Base(){
	  x = 100;
  }
  public  int getX()
  {
	  return x;
  }
  public  int getXx()
  {
	 return  getxxx();
  }
  private int getxxx()
  {
	  return x + x + x;
  }
}
