import javax.swing.*;

import java.awt.*;
//import javax.swing.event.*;
public class Gtest extends JFrame
{
    private static final int WIDTH = 350;
    private static final int HEIGHT = 100;

    public Gtest()
    {
        setTitle("Labels, fonts, and colors demonstration");

        setSize(WIDTH, HEIGHT);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args)
    {
        Gtest demoObject =  new Gtest();
    }
	
}
