import javax.swing.*;
import java.awt.*;
public class HelloWorld // extends JFrame
{
	   HelloWorld()
	   {
	     // super("Hello world!");
	     // addWindowListener();
	      JFrame f = new JFrame();
	      final int width = 400, height = 300;
	      Font font = new Font("Helvetica", Font.BOLD, 20);
	      f.setSize(width, height);
	      JLabel one   = new JLabel("Label one");
	      JLabel two   = new JLabel("Label two");
	      JLabel three = new JLabel("Label three");
	      JLabel four  = new JLabel("Label four");
	      JLabel five  = new JLabel("Label five");
	      one.setFont(font);
	      two.setFont(font);
	      three.setFont(font);
	      four.setFont(font);
	      five.setFont(font);
	    
	   /*   add(one,"East");
	      add(two,   "West");
	      add(three, "North");
	      add(four,  "South");
	      add(five,  "Center");	      
	      */
	      
	      f.add(one);
	      f.add(two);
	      f.add(three);
	      f.add(four);
	      f.add(five);
	      
	   }

}
