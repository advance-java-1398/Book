
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LabelsColorsFontsTwo extends JFrame
{
    private JLabel javaL, programmingL;

    private Container pane;

    private static final int WIDTH = 350;
    private static final int HEIGHT = 100;

    public LabelsColorsFontsTwo()
    {
        javaL = new JLabel("Java", SwingConstants.CENTER);
        programmingL = new JLabel("Programming",
                                  SwingConstants.CENTER);

        setTitle("Labels, fonts, and colors demonstration");

        pane = getContentPane();

        pane.setLayout(new GridLayout(1, 2));

        pane.add(javaL);
        pane.add(programmingL);

        setSize(WIDTH, HEIGHT);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args)
    {
        LabelsColorsFontsTwo demoObject =
                             new LabelsColorsFontsTwo();
    }

}
