import javax.swing.JFrame;
public class TreeTest
{
    public static void main(String[] args)
    {
      JFrame frame = new SimpleTree();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
    }

}
