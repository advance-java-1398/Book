public class Example7_8
{
    public static void main(String[] args)            //Line 3
    {                                                 //Line 4
        RectangleShape  rectangle, rectRef;           //Line 5
        BoxShape box, boxRef;                         //Line 6

        rectangle = new RectangleShape(12, 4);        //Line 7
        System.out.println("Line 8: Rectangle \n"
                           + rectangle+ "\n");        //Line 8

        box = new BoxShape(13, 7, 4);                 //Line 9
        System.out.println("Line 10: Box\n"
                           + box+ "\n");              //Line 10
        rectRef = box;                                //Line 11
        System.out.println("Line 12: Box via rectRef\n"
                           + rectRef+ "\n");          //Line 12


        boxRef = (BoxShape) rectRef;                  //Line 13
        System.out.println("Line 14: Box via boxRef"
                         + "\n" + boxRef + "\n");     //Line 14

        if (rectRef instanceof BoxShape)              //Line 15
            System.out.println("Line 16: rectRef "
                             + "is an instance of "
                             + "BoxShape");           //Line 16
        else                                          //Line 17
           System.out.println("Line 18: rectRef is "
                            + "not an instance of "
                            + "BoxShape");            //Line 18

        if (rectangle instanceof BoxShape)            //Line 19
            System.out.println("Line 20: rectangle "
                             + "is an instance of "
                             + "BoxShape");           //Line 20
        else                                          //Line 21
            System.out.println("Line 22: rectangle "
                             + "is not an instance "
                             + "of BoxShape");        //Line 22
    } //end main                                      //Line 23
}
