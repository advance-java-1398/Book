
public class Example7_4 {
	  public static void main(String[] args)
	  {
	     Sample s1 =  new Sample(5);
	     System.out.println("s1: " + s1);
	     Sample s2 = new Sample(10);
	     System.out.println("s1: " + s1);
	     System.out.println("s2: " + s2);
	     System.out.println("Sum of myValues: " + 
	    		 Sample.getSum());
	     System.out.println("Number of sample objects : " + 
	    		        Sample.getCount());
	  }

}
