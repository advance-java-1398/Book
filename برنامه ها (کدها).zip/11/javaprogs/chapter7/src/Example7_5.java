
public class Example7_5 {
	  public static void main(String[] args)
	  {
	    EmployeeServ emp = new EmployeeServ();
	    emp.setNum(100);
	    emp.setSal(1000000);
	    emp.setReg(2);
	    System.out.println("Number is : " + emp.getNum());
	    System.out.println("Salary is:" + emp.getSal());
	    System.out.println("Region is :" + emp.getReg());
	   }
}
