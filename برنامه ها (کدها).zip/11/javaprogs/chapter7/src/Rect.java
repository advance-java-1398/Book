
public class Rect extends GeometricShape
{
	  // *** data fields
	  protected double width; //input, essential attribute
	  protected double length; //input, essential attribute
	  // *** methods
	  // *** constructors
	  public Rect()
	  {
	     this(0, 0);
	  }
	  public Rect(double w, double l)
	  {
	    width = w;
	    length = l;
	  }
	  // *** modifires
	  public void setWidth(double w)
	  {
	    width = w;
	  }
	  public void setLength(double l)
	  {
	    length = l;
	  }
	  // *** accessors
	  public double getWidth()
	  {
	     return width;
	  }
	  public double getLength()
	  {
	    return length;
	  }
	  // *** operations
	  public void calculate()
	  {
	     area = length * width;
	     perimeter = 2 * (length + width);
	  }
	  public String toString()
	  {
	     return "Rectangle :" + "length = " +
	            length + ", " + "width = " + width;
	  }
}
