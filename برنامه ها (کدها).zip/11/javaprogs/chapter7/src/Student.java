import java.util.*;
public class Student {
	   static Scanner console = new Scanner(System.in);
	   protected String name;
	   protected long stNum;
	   protected float grade;
	   //*****
	   public void getInfo() 
	   {
	      System.out.print("Enter student name:");
	      name = console.next();
	      System.out.print("Enter student number:");
	      stNum = console.nextLong();
	      System.out.print("Enter student grade:");
	      grade = console.nextFloat();
	   }
	   //***
	   public void showInfo()
	   {
	      System.out.print(name.trim()+"\t\t");
	      System.out.print(stNum+"\t\t");
	      System.out.print(grade);
	   }
	   //**
	   public void showTitle()
	   {
	      System.out.println("\nName\t\t Number\t\t grade");
	   }
}
