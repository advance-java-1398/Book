
public class Sample {
	  //class data
	  private static int sum;
	  private static int count;
	  //instance data
	  private int myValue;
	  public Sample(int x)
	  {
	    myValue =  x;
	    count++;
	    sum += myValue;
	  }
	  //class accessors
	  public static int getSum()
	  {
	    return sum;
	  }
	  //***
	  public static int getCount()
	  {
	    return count;
	  }
	  //instance accessor
	  public int getMyValue()
	  {
	     return myValue;
	  }
	  //***
	  public String toString()
	  {
	    return (myValue+", " + sum + ", " +count);
	  }
}
