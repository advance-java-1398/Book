
public class BaseClass {
	public BaseClass()
	{
	   System.out.println("In the constructor of super class.");
	}
}
