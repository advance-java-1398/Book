
public class Example7_10
{
	   public static void main(String[] args)
	   {
	      Rect r = new Rect(10, 20);
	      Square sq = new Square(10);
	      Triangle t = new Triangle(5, 20);
	      System.out.println("<<< " + r.toString() + " >>>");
	      r.printMe();
	      System.out.println("<<< " + sq.toString() + " >>>");
	      sq.printMe();
	      System.out.println("<<< " + t.toString() + " >>>");
	      t.printMe();
	    }
}
