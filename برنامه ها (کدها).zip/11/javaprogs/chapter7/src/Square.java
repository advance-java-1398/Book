
public class Square extends Rect 
{
	   //*** methods
	   // *** constructors
	   public Square()
	   {
	   }
	   public Square(double side)
	   {
	      super(side, side);
	   }
	   // *** modifiers
	   public void setSide(double side)
	   {
	      width = side;
	      length = side;
	   }
	   public void setLength(double s)
	   {
	      setSide(s);
	   }
	   public void setWidth(double s)
	   {
	      setSide(s);
	   }
	   // *** accessor
	   public double getSide()
	   {
	     return width;
	   }
	   public String toString()
	   {
	     return "Square : " + "side = " + width;
	   }
}
