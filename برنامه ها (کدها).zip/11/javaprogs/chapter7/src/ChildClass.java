
public class ChildClass extends BaseClass {
	  public ChildClass()
	  {
	     System.out.println("In constructor of sub class.");
	  }
}
