public class Example7_2 {
	   public static void main(String[] arg)
	   {
	      PartTimeEmployee newEmp =
	            new PartTimeEmployee("Ali", "Ahmadian", 3000, 50.5);

	      System.out.println(newEmp);
	   }
}
