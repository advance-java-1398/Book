
public abstract class GeometricShape 
{
	  protected double area;
	  protected double perimeter;
	  public void printMe()
	  {
	    this.calculate();
	    System.out.printf("area = %6.2f  " , area);
	    System.out.printf("perimeter = %6.2f \n\n" , perimeter);
	  }
	  //abstract method
	  abstract protected void  calculate();
}
