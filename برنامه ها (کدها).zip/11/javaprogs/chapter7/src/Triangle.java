
public class Triangle extends GeometricShape
{
	   // data fields
	   protected double base;
	   protected double height;
	   // *** methods
	   // *** constructors
	   public Triangle()
	   {
	   }
	   public Triangle(double b, double h)
	   {
	     base = b;
	     height = h;
	   }
	   // *** modifires
	   public void setBase(double b)
	   {
	      base = b;
	   }
	   public void setHeight(double h)
	   {
	      height = h;
	   }
	   // *** accessors
	   public double getBase()
	   {
	      return base;
	   }
	   public double getHeight()
	   {
	     return height;
	   }
	   // *** operations
	   public void calculate()
	   {
	       area =  height * base / 2;
	       perimeter = height + base + 
	         Math.sqrt(height * height + base * base);
	   }
	   public String toString()
	   {
	      return "Right triangle : " + "height = " +
	               height + ", " + " base = " +base;
	   }
}
