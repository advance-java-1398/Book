import java.util.*;
public class Example7_6 {
	   static Scanner console = new Scanner(System.in);
	   private static Student[] stArray;
	   private static NightStudent[] nstArray;
	   public static void main(String[] args) 
	   {
	      askNumberStudent();
	      while(true)
	      {
	         switch(menu())
	         {
	           case 1:
	              enterDataDs();
	              break;
	           case 2:
	              showDataDs();
	              break;
	           case 3:
	              enterDataNs();
	              break;
	           case 4:
	              showDataNs();
	              break;
	           case 5:
	              System.exit(0);
	         }
	      }
	   }
	   //***
	   public  static void askNumberStudent() 
	   {
	      System.out.print("How many daily students?");
	      stArray = new Student[console.nextInt()];
	      System.out.print("How many night students?");
	      nstArray = new NightStudent[console.nextInt()];
	   }
	   //***
	   public static void enterDataDs() 
	   {
	     for(int i = 0; i < stArray.length; i++)
	     {
	          stArray[i] = new Student();
	          stArray[i].getInfo();
	      }
	   }
	   //***
	   public static void enterDataNs() 
	   {
	     for(int i = 0; i < stArray.length; i++)
	     {
	          nstArray[i] = new NightStudent();
	          nstArray[i].getInfo();
	      }
	   }
	   //***
	   public static void showDataDs() 
	   {
	     stArray[0].showTitle();
	     for(int i = 0; i < stArray.length; i++)
	     {
	          stArray[i].showInfo();
	     }
	     System.out.println("\n--------------------------------------");
	   }
	   public static void showDataNs() 
	   {
	     nstArray[0].showTitle();
	     for(int i = 0; i < stArray.length; i++)
	     {
	          nstArray[i].showInfo();
	     }
	     System.out.println();
	     for(int i = 0; i <= 55; i++)
	        System.out.print("-");
	     System.out.println();
	   }
	   //***
	   public static int menu() 
	   {
	      System.out.println("1. Enter  daily student data.");
	      System.out.println("2. Report daily student data.");
	      System.out.println("3. Enter  night student data.");
	      System.out.println("4. Report night student data.");
	      System.out.println("5. Exit.");
	      System.out.print("Enter your select(1-5) :");
	      return console.nextInt();
	   }

}
