import java.util.*;
public class NightStudent extends Student{
	   static Scanner console = new Scanner(System.in);
       private long tuition;
	   public void getInfo() 
	   {
	      System.out.print("Enter student name:");
	      name = console.next();
	      System.out.print("Enter student number:");
	      stNum = console.nextLong();
	      System.out.print("Enter student grade:");
	      grade = console.nextFloat();
	      System.out.print("Enter student tuition:");
	      tuition = console.nextLong();
	   }
	   //***
	   public void showInfo()
	   {
	      System.out.print(name.trim()+"\t\t");
	      System.out.print(stNum+"\t\t");
	      System.out.print(grade+"\t\t");
	      System.out.print(tuition);
	   }
	   //***
	   public void showTitle()
	   {
	      System.out.println("\nName\t\t Number\t\t grade\t\t Tuition");
	   }
}
