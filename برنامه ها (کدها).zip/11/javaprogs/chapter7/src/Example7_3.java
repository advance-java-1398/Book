
public class Example7_3 {
	  public static void main(String[] args)
	  {
	    ChildClass ch = new ChildClass();
	  }
}
