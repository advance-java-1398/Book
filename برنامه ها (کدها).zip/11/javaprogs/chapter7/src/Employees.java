
public class Employees {
	   protected long empNum;
	   protected long empSal;
	   protected void setNum(long num)
	   {
	      empNum = num;
	   }
	   //***
	   public void setSal(long sal)
	   {
	      empSal = sal;
	   }
	   //***
	   public long getNum()
	   {
	      return empNum;
	   }
	   //***
	   public long getSal()
	   {
	      return empSal;
	   }
}
