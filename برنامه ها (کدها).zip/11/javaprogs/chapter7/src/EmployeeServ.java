
public class EmployeeServ extends Employees {
	   private int empReg  ;
	   public void setReg(int reg)
	   {
	      empReg = reg;
	   }
	   //***
	   public int getReg()
	   {
	      return empReg;
	   }
}
