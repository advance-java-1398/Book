import java.util.*;
public class Example6_5 {
	static Scanner console = new Scanner(System.in);
    public static void main(String[] args)
    {
        int [] grades = new int [10];
        System.out.println("Enter 10 integer grades :");
        for(int i = 0; i < grades.length; i ++)
        	grades[i] = console.nextInt();
        selectionSort(grades, grades.length);
        System.out.println("After sorting, the "
                + "list elements are:");       

         for (int i = 0; i < 10; i++)                    
              System.out.print(grades[i] + " ");           

         System.out.println();                          

    }
    //****************
    public static void selectionSort(int[] list, int listLength)
    {
        int smallestIndex;
        int minIndex;
        int temp;

        for (int index = 0; index < listLength - 1; index++)
        {
                //Step a
            smallestIndex = index;

            for (minIndex = index + 1; minIndex < listLength;
                                       minIndex++)
                if (list[minIndex] < list[smallestIndex])
                    smallestIndex = minIndex;

                //Step b
            temp = list[smallestIndex];
            list[smallestIndex] = list[index];
            list[index] = temp;
        }
    } //end selectionSort

}
