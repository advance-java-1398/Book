import java.util.*;
public class Example6_16 {
	static Scanner console = new Scanner(System.in);
	public static void main(String[] args)
	{
        int high;
        PascalTriangle triangle = new PascalTriangle();
		System.out.print("enter the high of triangle :");
		high = console.nextInt();
		triangle.setHigh(high);
		triangle.buildTriangle();
        triangle.displayTriAngle();
	}
}
