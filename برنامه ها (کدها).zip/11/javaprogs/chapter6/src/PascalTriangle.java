public class PascalTriangle {
	private int [][] pasTri;
	private int high; //high of triangle
	public void setHigh(int h)
	{
		high = h;
	}
	//***********
	public void buildTriangle()
	{
	      pasTri = new int[high][];
	      //build the first row;
	      pasTri[0] = new int[1];
	      pasTri[0][0] = 1;
	      //build the remaining rows, one row at a time
	      int row = 1;
	      while(row < pasTri.length)
	      {
	         int lastRow[] = pasTri[row - 1];
	         int newRow[] = new int[row + 1];
	         //store 1 in first and last elements of the row
	         newRow[0] = 1;
	         newRow[newRow.length - 1] = 1;
	         //fill in the middle of the row
	         for(int i = 1; i < newRow.length - 1; i++)
	             newRow[i] = lastRow[i - 1] + lastRow[i];
	         pasTri[row] = newRow;
	         row++;
	      }
	}//End buildTriangle
	   public void displayTriAngle()
	   {
	      for(int i = 0; i < pasTri.length; i++)
	      {
	         for(int k = 0; k < (pasTri.length - i); k++)
	            System.out.print(" ");
	         for(int j = 0; j < pasTri[i].length; j++)
	            System.out.print(" "+pasTri[i][j]);
	         System.out.println();
	      }
	   } // End displYtRIANGLE
}
