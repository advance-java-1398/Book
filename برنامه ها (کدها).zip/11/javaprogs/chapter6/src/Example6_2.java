public class Example6_2
{
	  public static void main(String[] args) throws Exception
	  {
	    Exam st = new Exam();
	    st.getExamData();
	    st.showStats();
	  }
}
