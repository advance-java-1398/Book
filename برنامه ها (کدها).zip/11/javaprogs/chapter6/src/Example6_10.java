import java.util.*;
public class Example6_10 {
	static Scanner console = new Scanner(System.in);
	  private static Clerk[] clArray;
	  static boolean code = false;
	  public static void main(String[] args) 
	  {
	     askArraySize();
	     while(true)
	     {
	        switch(menu())
	        {
	           case 1:
	               enterData();
	               break;
	           case 2:
	               if (!code)
	               {
	                  System.out.println("You didn't enter any data!");
	                  break;
	               }
	               showData();
	               break;
	           case 3:
	               System.exit(0);
	        }
	     }
	  }
	  //***
	  public static void askArraySize() 
	  {
	     System.out.print("How many clerks work in organization ?");
	     clArray = new Clerk[console.nextInt()];
	  }
	  //***
	  public static void enterData() 
	  {
	    for(int i = 0; i < clArray.length; i++)
	   {
	      clArray[i] = new Clerk();
	      System.out.print("Enter name for clerk "+(i+1)+":");
	      clArray[i].setName(console.next());
	      System.out.print("Enter hours for clerk "+(i+1)+":");
	      clArray[i].setHours(console.nextFloat());
	      System.out.print("Enter rate for clerk "+(i+1)+":");
	      clArray[i].setRate(console.nextFloat());
	    }
	    code = true;
	  }
	  //***
	  public static int menu() 
	  {
	    System.out.println("1. Enter clerk data");
	    System.out.println("2. Report clerk data");
	    System.out.println("3. Exit");
	    System.out.print(" Enter your select(1-3):");
	    int choice = console.nextInt();
	    return choice;
	  }
	  //***
	  public static void showData()
	  {
	    float grossPay, netPay, sumNetSalary = 0;
	    System.out.println("Name \t\t Gross pay \t\t Net pay");
	    for(int i = 0; i < clArray.length; i++)
	    {
	       if(clArray[i].getHours() <= 40)
	          grossPay = clArray[i].getHours() * clArray[i].getRate();
	       else
	          grossPay =(40 * clArray[i].getRate()) +
	                     (clArray[i].getHours() - 40) *
	                     (float)1.5 * clArray[i].getRate();

	       netPay = grossPay - grossPay * 7 / 100;
	       sumNetSalary += netPay;
	       System.out.print(clArray[i].getName().trim()+"\t\t");
	       System.out.print(grossPay+"\t\t\t");
	       System.out.println(netPay);
	    }
	    System.out.println("\nThe mean of net pay is:"+sumNetSalary);
	  }
}
