import java.util.*;
public class Example6_1 {
	static Scanner console = new Scanner(System.in);
	public static void main(String[] args)
	{
		int items [] = new int[5];
		int i, sum;
        sum = 0;
		System.out.print("Enter five integers :");
        for(i = 0; i < items.length; i++)
		{
            items[i] = console.nextInt();
            sum += items[i];
        }
		System.out.println("The sum of the numbers is :" + sum);
		System.out.print("The numbers in the reverse order are :") ;
        for(i = items.length - 1; i >= 0; i--)
        {
        	System.out.print(items[i] + " ");
        }
	}
}
