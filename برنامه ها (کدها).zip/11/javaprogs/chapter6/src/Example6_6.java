import java.util.*;
public class Example6_6 {
	static Scanner console = new Scanner(System.in);
    public static void main(String[] args)
    {
        int [] numbers = new int [10];
        System.out.println("Enter 10 integer numbers :");
        for(int i = 0; i < numbers.length; i ++)
        	numbers[i] = console.nextInt();
        insertionSort(numbers, numbers.length);
        System.out.println("After sorting, the "
                + "list elements are:");       

         for (int i = 0; i < 10; i++)                    
              System.out.print(numbers[i] + " ");           
         System.out.println();                          
    }
    //**************************
    public static void insertionSort(int[] list, int listLength)
    {
        int location;
        int temp;

        for (int firstOutOfOrder = 1; firstOutOfOrder < listLength;
                                      firstOutOfOrder++)
            if (list[firstOutOfOrder] < list[firstOutOfOrder - 1])
            {
                temp = list[firstOutOfOrder];
                location = firstOutOfOrder;

                do
                {
                    list[location] = list[location - 1];
                    location--;
                }
                while (location > 0 && list[location - 1] > temp);

                list[location] = temp;
            }
    } //end insertionSort

}
