import java.util.*;
public class Example6_12 {
	   public static void main(String[] arg)                
	   {                                                    
	      Vector<String> stringList =
	                            new Vector<String>();       

	      System.out.println("Empty stringList?: "
	                        + stringList.isEmpty());        
	      System.out.println(" Size stringList?: "
	                        + stringList.size());           
	      System.out.println();                             

	      stringList.addElement("Spring");                  
	      stringList.addElement("Summer");                  
	      stringList.addElement("Fall");                    
	      stringList.addElement("Winter");                  
	      stringList.addElement("Sunny");                   

	      System.out.println(" **** After adding "
	                      + "elements to stringList ****"); 
	      System.out.println("Empty stringList?: "
	                      + stringList.isEmpty());          
	      System.out.println("Size stringList?: "
	                      + stringList.size());             
	      System.out.println("stringList: "
	                      + stringList);                    

	      System.out.println("stringList "
	                       + "contains Fall?: "
	                       + stringList.contains("Fall"));  
	      System.out.println();                             

	      stringList.insertElementAt("Cool", 1);            
	      System.out.println("**** After adding "
	                      + "an element at position "
	                      + "1 ****");                      
	      System.out.println("stringList: "
	                      + stringList);                    

	      System.out.println();                             

	      stringList.removeElement("Fall");                 
	      stringList.removeElementAt(2);                    
	      System.out.println("**** After the "
	                      + "remove operations ****");      
	      System.out.println("stringList: "
	                      + stringList);                    
	      System.out.println("Size stringList?: "
	                      + stringList.size());             
	      System.out.println("indexOf(\"Sunny\"): "
	                      + stringList.indexOf("Sunny"));   
	   }                                                    
}
