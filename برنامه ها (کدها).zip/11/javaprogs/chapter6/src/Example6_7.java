import java.util.*;
public class Example6_7 {
	static Scanner console = new Scanner(System.in);
    static final int ARRAY_SIZE = 10;                   
    public static void main(String[] args)
    {
        int[] intList = new int[ARRAY_SIZE];           
        int number;                                     
        int index;                                      
        System.out.println("Enter " + ARRAY_SIZE + " integers :");  
        for (index  = 0; index < ARRAY_SIZE; index++)   
            intList[index] = console.nextInt();         
        System.out.println();                           
        System.out.print("Enter the number to find: ");                  
        number  = console.nextInt();                    
        System.out.println();                           
        index = seqSearch(intList,  intList.length,  number);        
        if (index != -1)                                
            System.out.println(number + " is found at position " + index);                  
        else                                            
            System.out.println(number + " is not in the list.");   
     }
    //******************
     public static int seqSearch(int[] list, int listLength,
            int searchItem)
     {
       int loc;
       boolean found = false;
       loc = 0;
       while (loc < listLength && !found)
       if (list[loc] == searchItem)
           found = true;
        else
           loc++;
       if (!found)
            loc = -1;  //it is an unsuccessful search
       return loc;
     } //end seqSearch
}
