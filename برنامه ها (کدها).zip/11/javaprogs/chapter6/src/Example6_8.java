import java.util.*;
public class Example6_8 {
	static Scanner console = new Scanner(System.in);
    static final int ARRAY_SIZE = 10;                   
	public static void main(String[] args)
	{
        int[] intList = new int[ARRAY_SIZE];           
        int number;                                     
        int index;                                      
        System.out.println("Enter " + ARRAY_SIZE + " sorted  integers :");  
        for (index  = 0; index < ARRAY_SIZE; index++)   
            intList[index] = console.nextInt();         
        System.out.println();                           
        System.out.print("Enter the number to find: ");                  
        number  = console.nextInt();                    
        System.out.println();                           
        index = binarySearch(intList,  intList.length,  number);        
        if (index != -1)                                
            System.out.println(number + " is found at position " + index);                  
        else                                            
            System.out.println(number + " is not in the list.");   
		
	}
	//*******************
    public static int binarySearch(int[] list, int listLength,
    		                       int searchItem)
    {
        int first = 0;
        int last = listLength - 1;
        int mid = 0;
        boolean found = false;
        while (first <= last && !found)
        {
            mid = (first + last) / 2;

            if (list[mid] == searchItem)
                found = true;
            else if (list[mid] > searchItem)
                last = mid - 1;
            else
                first = mid + 1;
        }

        if (!found)
            mid = -1; //it is an unsuccessful search
        return mid;
    }//end binarySearch
}
