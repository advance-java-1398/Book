public class Example6_3 {
	   public static void main(String[] args)
	   {
	      int x[] = {5, 10, 15, 20};
	      System.out.println("In main method:");
	      System.out.println("x[0] = " + x[0]+", x[3] = " + x[3]);
	      System.out.println("--------------------");
	      testTrans(x[0], x[3]);
	      System.out.println("--------------------");
	      System.out.println("Back from method to main method:");
	      System.out.println("x[0] = " + x[0]+", x[3] = " + x[3]);
	    }
	    //***
	    private static void testTrans(int a, int b)
	    {
	      a++;
	      b ++;
	      System.out.println("In testTrans method:");
	      System.out.println("a = " + a +", b = " + b);
	    }

}
