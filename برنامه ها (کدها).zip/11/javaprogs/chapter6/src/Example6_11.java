import java.util.*;
public class Example6_11 {
	static Scanner console = new Scanner(System.in);
	  private static String[] master;
	  public static void main(String[] args) 
	  {
	     askArraySize();
	     enterData();
	     String name = new String();
	     System.out.print("Enter a name to search:");
	     name = console.next();
	     if(seqSearch(name) == -1)
	        System.out.print("Master '"+name.trim()+"' not exist.");
	     else
	        System.out.print("Master '"+name.trim()+"' exist.");

	  }
	  //***
	  public static void askArraySize() 
	  {
	     System.out.print("How many masters work in faculty ?");
	     master = new String[console.nextInt()];
	  }
	  //***
	  public static void enterData() 
	  {
	    for(int i = 0; i < master.length; i++)
	   {
	      master[i] = new String();
	      System.out.print("Enter name for master "+(i+1)+":");
	      master[i] = console.next();
	   }
	  }
	  //***
	  public static int seqSearch(String name)
	  {
	      for(int i = 0; i < master.length; i++)
	         if(master[i].equalsIgnoreCase(name))
	            return i;
	      return -1;
	  }
}
