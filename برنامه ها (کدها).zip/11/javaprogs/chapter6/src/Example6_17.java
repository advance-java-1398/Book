import java.util.*;
public class Example6_17 {
	static Scanner console = new Scanner(System.in);
	public static void main(String[] args)
	{
		Temprature mehrMonth = new Temprature();
		int numDay;
		System.out.println("Enter number of days in Mehr:");
		numDay = console.nextInt();
		int minT[] = new int[numDay];
		int maxT[] = new int[numDay];
		System.out.println("Enter daily maximum " 
				      + "tempratures for mehrMonth");
		for(int i = 0; i < numDay; i++)
			maxT[i] = console.nextInt();
		System.out.println();
		
		System.out.println("Enter daily minum "
				  + "tempratures for mehrMonth");
		for(int i = 0; i < 31; i ++)
			minT[i] = console.nextInt();
		System.out.println();
        mehrMonth.setTemp(maxT, minT, 31);		
        System.out.println("mehrMonth \n" + mehrMonth);
	}
}
