
public class Example6_4 {
   public static void main(String[] args)
   {
      int x[] = {5, 10, 15, 20};
      System.out.println("In main method:");
      for(int i = 0; i < x.length; i++)
         System.out.print("x["+i+"]="+x[i]+"\t");
      System.out.println("\n--------------------");
      testTrans(x);
      System.out.println("\n--------------------");
      System.out.println("Back from method to main method:");
      for(int i = 0; i < x.length ; i++)
         System.out.print("x[" + i + "] = " + x[i] + "\t");
    }
    //***
    private static void testTrans(int x[])
    {
      for(int i = 0; i < x.length; i++)
          x[i] *= x[i];
      System.out.println("In testTrans method after change :");
      for(int i = 0; i < x.length; i++)
         System.out.print("x[" + i + "]=" + x[i] + "\t");
    }

}
