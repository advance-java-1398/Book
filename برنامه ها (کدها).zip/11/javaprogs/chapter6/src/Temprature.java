
public class Temprature {
	private int daysInMonth;
	private int [] maxTemp;
	private int [] minTemp;
	public Temprature()
	{
		daysInMonth = 0;
		maxTemp = new int[31];
		minTemp = new int[31];
	}
    //***********
	public Temprature(int[] maxT, int[] minT, int daysInM)
	{
		daysInMonth = daysInM;
		maxTemp = new int[daysInM];
		minTemp = new int[daysInM];
		setTemp(maxT, minT, daysInM);
	}
	//**************
	public void setTemp(int[] maxT, int[] minT, int daysInM)
	{
		if(0 <= daysInM && daysInM <= 31)
		{
			daysInMonth = daysInM;
		    for(int i = 0; i < daysInMonth; i ++)
		    {
		    	maxTemp[i] = maxT[i];
		    	minTemp[i] = minT[i];
		    }
		}
		else
		{
			System.out.println("Number of days in month "
					+ "is out of range");
			daysInMonth = 0;
		}
	}
	//**************
	public int monthMaxTempDay()
	{
		int day = 0;
		for(int i = 1; i < daysInMonth; i++)
			if(maxTemp[day] < maxTemp[i])
				day = i;
		return day;
	}
	//**************8
	public int averageMaxTemp()
	{
		int sum = 0;
		for(int i = 0; i < daysInMonth; i++)
             sum += maxTemp[i];
		if(daysInMonth != 0)
			return sum / daysInMonth;
		else
			return -1;
	}
	//*************
	public int monthMinTempDay()
	{
		int day = 0;
		for(int i = 1; i < daysInMonth; i++)
			if(minTemp[day] > minTemp[i])
				day = i;
		return day;
	}
	//*************
	public int averageMinTemp()
	{
		int sum = 0;
		for(int i = 0; i < daysInMonth; i++)
             sum += minTemp[i];
		if(daysInMonth != 0)
			return sum / daysInMonth;
		else
			return -1;
	}
	//**************
	public String toString()
	{
		String str;
		str = "Maximum temprature : "
			+ maxTemp[monthMaxTempDay()] + "\n"
			+ "Minimum temprature : "
			+ minTemp[monthMinTempDay()] + "\n"
			+ "Average maximum temprature: "
			+ averageMaxTemp() + "\n"
			+ "Average minimum temprature: "
			+ averageMinTemp() + "\n";
		return str;
	}
	//************

}
