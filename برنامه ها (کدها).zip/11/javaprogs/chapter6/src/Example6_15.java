
public class Example6_15 {
   public static void main(String[] args) throws Exception
   {
     matMultiply mat = new matMultiply();
     mat.askMatDim();
     mat.showMultiply();
   }
}
