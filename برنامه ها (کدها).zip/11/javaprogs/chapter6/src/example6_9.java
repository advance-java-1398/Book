import java.util.*;
public class example6_9 {
    static Scanner console = new Scanner(System.in);   

    public static void main(String[] args)             
    {                                                  
        ArrayListClass myList =
                       new ArrayListClass(10);         
        ArrayListClass yourList =
            new ArrayListClass(10);         
        int num;                                       

        System.out.println(" Enter "
                       + myList.listSize()
                       + " integers: ");               

        for (int index = 0;
             index < myList.listSize(); index++)       
        {                                              
            num = console.nextInt();                   
            myList.insertEnd(num);                     
        }                                              
        System.out.println();                          
        System.out.println(" Before sorting "
                         + "myList:\n" + myList);      
        myList.selectionSort();                        

        System.out.println("After sorting "
                         + "myList: \n " + myList);   
        int indexLargest = 
        	       myList.indexLargestElement();
        System.out.println("The position of the largest " 
                     + "element in myList is " + indexLargest);
        System.out.println("The largest element in myList is : "
        		          + myList.elementAt(indexLargest));
        
        yourList.makeCopy(myList);
        System.out.println("yourList after copying myList : \n " 
        		+ yourList);
        
    } //end main                                       
}
