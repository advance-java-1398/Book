public class Clerk {
    private float hours;
    private float rate;
    private String name;
    public void setHours(float h)
    {
       hours = h;
    }
    //***
    public void setRate(float r)
    {
       rate = r;
    }
    //***
    public float getHours()
    {
       return hours;
    }
    //***
    public float getRate()
    {
       return rate;
    }
    //***
    public void setName(String s)
    {
       name = s;
    }
    //***
    public String getName()
    {
       return name;
    }
}
