import java.util.*;
public class Example8_1 
{
	public static void main(String[] args)
	{
		Student [] st = new Student[5];
		st[0] = new Student("Milad Ghomi", 19.5);
		st[1] = new Student("Reza Saberi", 12.8);
		st[2] = new Student("Ali Ahmadi", 16.5);
		st[3] = new Student("Mohsen Alavi",14.5);
		st[4] = new Student("Abbas Razavi", 11.5);
		
		Arrays.sort(st);
		System.out.println("Students after sorting :");
		for(Student s : st)
			System.out.println("name = " + s.getName() + " ," +
					"grade = " + s.getGrade());
	}
}
