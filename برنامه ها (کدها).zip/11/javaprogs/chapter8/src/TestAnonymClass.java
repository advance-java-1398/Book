public class TestAnonymClass
{
	String message = "";
	public TestAnonymClass(String s)
	{
		message = s;
	}
	//The original display method
	public void display()
	{
		System.out.println("Basic TestAnonymClass output :" + message);
	}
}
