public class Example8_4 
{
	//Here is where the anonymous class is define and instantiate
	public static void main(String[] args)        //line4
	{
		Runnable runner = new Runnable()          //line6
		{
			int total = 0;                        //line 8
			public void run()                     //line 9
			{                                     //line 10
				for(int i = 0; i < 1000000; i++)  //line 11
				{                                 //line 12 
					total ++;                     //line 13
				}                                 //line 14   
				System.out.println(Integer.toString(total));
			}                                     //line 16
		};                                        //line 17
		runner.run();                             //line 18
	}
}
