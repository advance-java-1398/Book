public class Student  implements Comparable<Student>
{
	private String stName;
	private double grade;
	public Student(String name, double score)
	{
		stName = name;
		grade = score;
	}
	
	public String getName()
	{
		return stName;
	}
	
	public double getGrade()
	{
		return grade;
	}
	
	public void changeGrade(double newGrade)
	{
		grade = newGrade;
	}
	public int compareTo(Student obj)
	{
		if(grade < obj.grade)
			return -1;
		if(grade > obj.grade)
			return 1;
		return 0;
	}
}
