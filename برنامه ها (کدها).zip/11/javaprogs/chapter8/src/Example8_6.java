public class Example8_6 
{
	public static void main(String[] args)
	{
		MainClass exam = new MainClass();
	}
}
