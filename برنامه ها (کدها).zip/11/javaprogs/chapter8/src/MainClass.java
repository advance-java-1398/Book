public class MainClass 
{
    //Anonymous member class extends TestAnonymClass
	TestAnonymClass anonym1  = new TestAnonymClass("Hello")     //line 3
	{
		//The original display method
		public void display()
		{
			System.out.println("Inherited anonymous overriden MEMBER display " +
					"TestAnonymClass output : " + message);
		}                                                                      //line9
	};
	public MainClass()                 
	{
		TestAnonymClass obj = new TestAnonymClass("Hello");
		//display the anonymous version
		obj.display();
		TestAnonymClass anonym2 = new TestAnonymClass("Hello")       //line 16
		{
			//The original display method
			public void display()
			{
				System.out.println("Inherited anonymous overriden LOCLA display " + 
						" TestAnonymClass output: " + message);  
			}
		};                                                         //line 23
		//display the anonymous class based on TestAnonymClass
		anonym2.display();
		//display the anonymous class based on TestAnonyClass
		this.anonym1.display();
	}
}
