public class StaticInnerClassTest 
{
    private static int a = 15;
    public static class stClass
    {
    	public void increment()
    	{
    		a ++;
    	}
    	//****************
    	public void display()
    	{
    		System.out.println("In static inner class : a = " + a);
    	}
    }
    //****************
    public void show()
    {
		System.out.println("In Outer class : a = " + a);
    }
}
