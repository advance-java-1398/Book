public class Example8_2
{
    public static void main(String s[])
    {
        //fill the array with integer values and
    	//print out only values of even indices
        OuterClass oc = new OuterClass();
        oc.printEven();
    }
}
