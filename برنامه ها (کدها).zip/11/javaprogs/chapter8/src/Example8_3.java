public class Example8_3
{
	public static void main(String[] args)
	{
     	OuterInnerClass oi = new OuterInnerClass();
     	oi.outerMethod();
	}
}
