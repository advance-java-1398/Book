public class OuterInnerClass
{
	private int outVar;                                                  //line 3
	void outerMethod()                                                   //line 4
	{                                                                    //line 5
		final int a = 10;                                                //line 6 
		int b = 100;                                                     //line 7
		System.out.println("In outerMethod a = " + a);                   //line 8 
		class InnerClass                                                 //line 9
		{                                                                //line 10
			void innerMethod()                                           //line 11  
			{                                                            //line 12
				//b = b + 10 // cannot access non final variable         //line 13 
				outVar = 100;                                            //line 14
				System.out.println("In innerMethod a = " + a);           //line 15
				System.out.println("In innerMethod outVar = " + outVar); //line 16
			}                                                            //line 17
		}                                                                //line 18
		InnerClass in = new InnerClass();                                //line 19 
		in.innerMethod();                                                //line 20
	}                                                                    //line 21
}
