public class Example8_7
{
	public static void main(String [] args)
	{
		StaticInnerClassTest.stClass  si = new 
		                   StaticInnerClassTest.stClass();
        si.increment();
        si.display();

        StaticInnerClassTest st = new StaticInnerClassTest();
        st.show();
	}
}
