public class Example8_5 
{
	public static void main(String[] args)
	{
		Runnable runObj = new Runnable()                //line 5
		{
			private static final int SIZE = 100;        //line 7
			private int[] x =  new int[SIZE];           //line 8
			//instance initialization code
			{                                           //line 10
				for (int i = 0; i < SIZE; i ++)
					x[i] = i;
			}                                           //line 13
			//************
			public void run()                           //line 14
			{
				int total = 0;
				for(int i = 0; i < SIZE; i ++)
					total += x[i];
				//System.out.println(Integer.toString(total));
				System.out.println("Sum of array elements : " + total);
			}                                           //line 21
		};                                              //line 22
		runObj.run();                                   //line 23
	}
}
