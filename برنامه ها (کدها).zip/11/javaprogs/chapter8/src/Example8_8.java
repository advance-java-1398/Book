public class Example8_8 
{
	public static void main(String[] arg)
	{
		PersonalInfo newStudent = new PersonalInfo("Reza",
		                             "Razavi", 8, 24, 1355,
		                              568986488);

		System.out.println(newStudent);
	}
}
