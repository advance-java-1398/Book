
public class Example3_3 {
    public static void main(String[] args){
    	for(float f = 15; f <= 18; f += 0.5)
    		System.out.println("f = " + f);
    }
}
