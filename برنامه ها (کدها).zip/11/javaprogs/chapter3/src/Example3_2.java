
public class Example3_2 {
   static public void main(String[] args){
	   for(char ch = 'A'; ch <= 'F';  ch++)
		   System.out.println(ch + " = " + (int) ch);
   }
}