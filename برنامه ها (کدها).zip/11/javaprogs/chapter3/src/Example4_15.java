import java.util.*;
public class Example4_15 {
	static Scanner console = new Scanner(System.in);
	public static void main(String[] args){
		int n;
		System.out.print("Enter a number :");
		n = console.nextInt();
		System.out.println("n = " + n + ", fact(n) = " + fact(n));
	}
	public static long fact(int n) {
		if(n != 0)
			return n * fact(n - 1);
		return 1;
	}

}
