import java.util.*;
public class Example2_7 {
    static Scanner in = new Scanner(System.in); 
	public static void main(String[] args){
		int num, digit;
		System.out.print("Enter an integer number : ");
		num = in.nextInt();
		do{
			digit = num %10;
			System.out.print(digit);
			num /= 10;
		} while(num != 0);
	}
}
