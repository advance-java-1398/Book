import java.awt.Color;
import javax.swing.JFrame;

public class Example12_5
{
   public static void main( String args[] )
   {
     // create frame for Shapes2JPanel
     JFrame frame = new JFrame( "Drawing 2D Shapes" );
     frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

     ShapesJpanel shapes = new ShapesJpanel();
     frame.add( shapes ); // add shapes2JPanel to frame
     //set frame background color
     frame.setBackground( Color.WHITE ); 
     frame.setSize( 400, 400 ); // set frame size
     frame.setVisible( true ); // display frame
   } // end main
}



