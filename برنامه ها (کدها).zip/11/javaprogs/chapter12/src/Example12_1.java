import java.awt.Color;
import javax.swing.JFrame;

public class Example12_1
{
    public static void main( String args[] )
	{
	   // create frame for LinesRectsOvalsJPanel
	   JFrame frame =
	   new JFrame( "Drawing lines, rectangles and ovals" );
	   frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	
	   DrawShapes dShape =  new DrawShapes();
	   dShape.setBackground( Color.WHITE );
	   frame.add( dShape ); // add panel to frame
	   frame.setSize( 400, 210 ); // set frame size
	   frame.setVisible( true ); // display frame
	} // end main
}




