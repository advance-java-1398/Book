  import java.awt.Color;
  import java.awt.Graphics;
  import javax.swing.JPanel;

public class DrawShapes extends JPanel
{
     public void paintComponent( Graphics g )     //line 7
     {
        super.paintComponent( g );                //line 9

        this.setBackground( Color.WHITE );        //line 11

        g.setColor( Color.RED );                  //line 13
        g.drawLine( 5, 30, 380, 30 );             //line 14

        g.setColor( Color.BLUE );                 //line 16
        g.drawRect( 5, 40, 90, 55 );              //line 17
        g.fillRect( 100, 40, 90, 55 );            //line 18
	
        g.setColor( Color.CYAN );                 //line 20
        g.fillRoundRect( 195, 40, 90, 55, 50, 50 );//line 21
        g.drawRoundRect( 290, 40, 90, 55, 20, 20 );//line 22
	
        g.setColor( Color.YELLOW );                //line 24
        g.draw3DRect( 5, 100, 90, 55, true );      //line 25
        g.fill3DRect( 100, 100, 90, 55, false );   //line 26
	
        g.setColor( Color.MAGENTA );               //line 28
        g.drawOval( 195, 100, 90, 55 );            //line 29
        g.fillOval( 290, 100, 90, 55 );            //line 30
     } // end method paintComponent                //line 31
}




