import javax.swing.JFrame;
public class Example12_3
{
    // execute application
    public static void main( String args[] )
    {
        // create frame for PolygonsJPanel
        JFrame frame = new JFrame( "Drawing Polygons" );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        DrawPolygon polygonsJPanel = new DrawPolygon();
        frame.add( polygonsJPanel ); // add polygonsJPanel to frame
        frame.setSize( 280, 270 ); // set frame size
        frame.setVisible( true ); // display frame
     } // end main
}


