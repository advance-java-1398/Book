import javax.swing.JFrame;
public class Example12_4
{
   public static void main( String args[] )
   {
       // create frame for ShapesJPanel
       JFrame frame = new JFrame( "Drawing 2D shapes" );
       frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

       // create ShapesJPanel
       ShapesDraw shapesJPanel = new ShapesDraw();

       frame.add( shapesJPanel ); // add shapesJPanel to frame
       frame.setSize( 425, 200 ); // set frame size
       frame.setVisible( true ); // display frame
   } // end main
}



