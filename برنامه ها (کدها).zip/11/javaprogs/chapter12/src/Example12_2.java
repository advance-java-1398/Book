import javax.swing.JFrame;

public class Example12_2
{
     // execute application
     public static void main( String args[] )
     {
        // create frame for ArcsJPanel
        JFrame frame = new JFrame( "Drawing Arcs" );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        DrawArcs arcsJPanel = new DrawArcs(); // create DrawArcs
        frame.add( arcsJPanel ); // add DrawArcs to frame
        frame.setSize( 300, 210 ); // set frame size
        frame.setVisible( true ); // display frame
     } // end main
}





