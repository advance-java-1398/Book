import java.awt.*;
import javax.swing.*;
public class Machine extends Player
{
  public Machine(String name, TicTacToe ap)
  {
    super(name, ap);
  }
  //*********
  public void takeTurn()
  {
    JButton b = findMove();
    if(b != null)
    {
      b.setText(name);
      b.setEnabled(false);
      ap.nextPlayer();
    }
    else
      ap.errorFound("machine player can't make a move.");
   }
   //********
   private JButton findMove()
   {
     for(int r = 0; r < 3; r++)
        for(int c = 0; c < 3; c++)
        {
           JButton b = ap.position(r, c);
           if(b.isEnabled())
              return b;
        }
     return null;
   }
}
