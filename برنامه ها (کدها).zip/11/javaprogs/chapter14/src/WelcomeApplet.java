import java.awt.Graphics;  
import javax.swing.JApplet; 
public class WelcomeApplet extends JApplet
{
  public void paint( Graphics g )                           
  {                                                         
    // draw a String at x-coordinate 25
    //and y-coordinate 25
    g.drawString( "Welcome to Java Programming!", 25, 25 );
  } // end method paint                                     
} // end class WelcomeApplet


