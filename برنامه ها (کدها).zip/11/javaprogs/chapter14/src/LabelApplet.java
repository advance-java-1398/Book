import javax.swing.*;
import java.awt.*;
public class LabelApplet extends JApplet
{
  JLabel label = new JLabel("Add a label to Applet");
  public void init()
  {
    Font bigFont = new Font("Helvetica", Font.BOLD, 18);
    label.setFont(bigFont);
    add(label);
  }
}


