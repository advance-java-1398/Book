import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DrawApplet extends JApplet
        implements MouseListener, MouseMotionListener
{
  private int xPos, yPos;
  public void init()
  {
    setBackground(Color.black);
    addMouseListener(this);
    addMouseMotionListener(this);
  }
  //implementing MouseListener
  public void mouseClicked(MouseEvent e)
  {
    ;
  }
  public void mouseEntered(MouseEvent e)
  {
     setBackground(Color.white);
     repaint();
  }
  public void mouseExited(MouseEvent e)
  {
    setBackground(Color.black);
    repaint();
  }
  public void mousePressed(MouseEvent e)
  {
    xPos = e.getX();
    yPos = e.getY();
  }
  public void mouseReleased(MouseEvent e)
  {
    ;
  }
  //implementing MouseMotionListener
  public void mouseDragged(MouseEvent e)
  {
    getGraphics().drawLine(xPos, yPos, e.getX(), e.getY());
    xPos = e.getX();
    yPos = e.getY();
  }
  public void mouseMoved(MouseEvent e)
  {
    ;
  }
}
