import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ClikCountApplet  extends JApplet
                       implements ActionListener
{
   private JButton aButton = new JButton("Click me");
   private int clickCount = 0;
   Font font = new Font("Helvetica", Font.BOLD, 18); 
   public void init()
   {
     aButton.setBackground(Color.green);
     aButton.setFont(font);
     add(aButton);
     aButton.addActionListener(this);
   }
   //************
   public void actionPerformed(ActionEvent e)
   {
     //change color after each press.
     if(aButton.getBackground() == Color.red)
         aButton.setBackground(Color.green);
     else
         aButton.setBackground(Color.red);
     clickCount++;
     
     aButton.setText("Click count me : " + clickCount);
   }
}
