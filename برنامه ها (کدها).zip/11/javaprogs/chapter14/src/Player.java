public abstract class Player
{
   protected String name = "";
   protected TicTacToe ap;
   public Player(String na, TicTacToe a)
   {
      name = na;
      ap = a;
   }
   public abstract void takeTurn();
   public String getName()
   {
      return name;
   }
}

