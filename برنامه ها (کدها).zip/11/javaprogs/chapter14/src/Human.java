import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Human extends Player implements ActionListener
{
  public Human(String name, TicTacToe ap)
  {
    super(name, ap);
  }
  public void takeTurn()
  {
    //active all buttons
    for(int r= 0; r < 3; r++)
       for(int c = 0; c < 3; c++)
       {
         JButton b = ap.position(r, c);
         if(b.isEnabled())
            b.addActionListener(this);
       }
   }
   //******
   public void actionPerformed(ActionEvent e)
   {
     JButton b = (JButton) e.getSource();
     b.setText(name);
     b.setEnabled(false);
    for(int r= 0; r < 3; r++)
       for(int c = 0; c < 3; c++)
       {
         JButton bt = ap.position(r, c);
         if(bt.isEnabled())
            bt.removeActionListener(this);
       }
       ap.nextPlayer();
   }
}

