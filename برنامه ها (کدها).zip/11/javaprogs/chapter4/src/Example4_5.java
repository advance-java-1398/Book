
public class Example4_5 {
	  public static void main(String[] args)
	  {
	    Date d1 = new Date();
	    Date d2 = new Date(10, 20, 2009);
	    System.out.print("Date d1 is :");
	    d1.showDate();
	    System.out.print("Date d2 is :");
	    d2.showDate();
	  }

}
