
public class Date1 {
	  private int month;
	  private int day;
	  private int year;
	  Date1()
	  {
	     this(8, 12,2009);
	  }
	  //********************
	   Date1(int m, int d, int y)
	   {
	    setDate(m, d, y);
	   }
	  //********************
	  public void setDate(int m, int d, int y)
	  {
	     month = m;
	     day   = d;
	     year = y;
	  }
	  //*********************
	  void showDate()
	  {
	     System.out.println(month+"/"+day+"/"+year);
	  }

}
