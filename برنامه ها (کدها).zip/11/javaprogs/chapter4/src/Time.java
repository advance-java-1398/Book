
public class Time {
	  private int hour;
	  private int minute;
	  private int second;
	  Time(int h, int m, int s)
	  {
	     hour = h;
	     minute = m;
	     second = s;
	  }
	  //*********************
	  void showTime()
	  {
	     System.out.println(hour+":"+minute+":"+second);
	  }

}
