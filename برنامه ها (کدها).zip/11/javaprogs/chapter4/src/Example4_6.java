
public class Example4_6 {
	  public static void main(String[] args)
	  {
	    Date1 d1 = new Date1();
	    Date1 d2 = new Date1(10, 20, 2009);
	    System.out.print("Date d1 is :");
	    d1.showDate();
	    System.out.print("Date d2 is :");
	    d2.showDate();
	  }

}
