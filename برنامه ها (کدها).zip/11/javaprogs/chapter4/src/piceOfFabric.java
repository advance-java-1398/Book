
import java.util.*;
public class piceOfFabric {
	static Scanner in = new Scanner(System.in);
	
    private double sqMeters;
    public void readSqMeters() {
        System.out.print("Enter fabric size in meters:");
    	sqMeters = in.nextDouble();
    }
    //**********
    public double toSqYards() {
    	return sqMeters * 1.96;
    }
    //**********
    public void displayFabric() {
    	System.out.print("Fabric size is : " + sqMeters + " meters");
    	System.out.println(" and "+ toSqYards() + " yards.");
    }
}
