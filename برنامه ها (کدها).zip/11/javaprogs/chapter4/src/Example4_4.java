
public class Example4_4 {
	   public static void main(String[] args){
		   Time tm1 = new Time(12, 10, 30);
		   Time tm2 = new Time(8, 30, 40);
		   System.out.print("Time tm1 = ");
		   tm1.showTime();
		   System.out.print("Time tm2 = ");
		   tm2.showTime();
	   }
	}
