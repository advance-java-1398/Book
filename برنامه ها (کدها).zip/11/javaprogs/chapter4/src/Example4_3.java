
public class Example4_3 {
	  public static void main(String[] args)
	  {
	     simpleControl control = new simpleControl();
	     control.setTemperature(25.0);
	     System.out.println("Temperature is :" + control.getTemperature());
	  }

}
