///import employeePackage.empDate;
import employeePackage.employee;
public class Example4_8 {
	  public static void main(String[] args)
	  {
	   employee e1 = new employee(100, 1000000);
	   employee e2 = new employee(200, 1500000);
	   e1.display();
	   e2.display();
	  }

}
