package employeePackage;

public class empDate {
	   public int month;
	   public int day;
	   public int year;
	   empDate()
	   {
	      month = 10;
	      day = 12;
	      year =2009;
	   }

}
