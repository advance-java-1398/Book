package employeePackage;

public class employee {
	  private int no;
	  private int salary;
	  private empDate entryDate = new empDate() ;
	  public employee(int num, int sal)
	  {
	     no = num;
	     salary = sal;
	  }
	  public void display()
	  {
	     System.out.println("Employee no = "+no + ", salary = "+salary);
	     System.out.print("Date of hire is :");
	     System.out.println(entryDate.month+"/"+entryDate.day+"/"+entryDate.year);
	     System.out.println("******************");

	  }

}
