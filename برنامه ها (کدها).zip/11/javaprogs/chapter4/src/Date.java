
public class Date {
	  private int month;
	  private int day;
	  private int year;
	  Date()
	  {
	     setDate(8, 12,2009);
	  }
	  //********************
	   Date(int m, int d, int y)
	   {
	    setDate(m, d, y);
	   }
	  //********************
	  public void setDate(int m, int d, int y)
	  {
	     month = m;
	     day   = d;
	     year = y;
	  }
	  //*********************
	  void showDate()
	  {
	     System.out.println(month+"/"+day+"/"+year);
	  }

}
