
public class staticTest {
      private int x;
      private static int count;
      //default constructor
      public staticTest(){
    	  x = 0;
      }
      //constructor with parameter
      public staticTest(int a){
    	  x = a;
      }
      //method to set x(a mutator method)
      void setX(int a){
    	  x = a;
      }
      //method return instance variable(accesor)
      public int getX(){
    	  return x;
      }
      //method return static variable
      public int getCount(){
    	  return count;
      }
      //method increment to private static variable
      public static void incrementCount(){
    	  count ++;
      }
      //method that return the values of
      //static and non static variables as string
      public String toString(){
    	  return("x = " + x + " and count = " + count);
      }
}     

