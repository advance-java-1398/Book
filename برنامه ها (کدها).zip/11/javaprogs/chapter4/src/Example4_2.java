
public class Example4_2 {
       public static void main(String[] args){
    	   rectangle rect = new rectangle();
    	   rect.readSides();
    	   rect.caculate();
    	   rect.display();
       }
}
