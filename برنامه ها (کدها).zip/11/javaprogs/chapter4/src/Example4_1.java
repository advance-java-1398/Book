public class Example4_1 {
	 public static void main(String[] args){ 
		piceOfFabric apiece = new piceOfFabric();
		apiece.readSqMeters();
		apiece.displayFabric();
	}

}
