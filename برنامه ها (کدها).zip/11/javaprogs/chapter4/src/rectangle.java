import java.util.Scanner;
public class rectangle {
	static Scanner in = new Scanner(System.in);
	private int length;
	private int width;
	private int area;
	private int perime;
	public void readSides(){
		System.out.print("Enter length and width :");
		length = in.nextInt();
		width = in.nextInt();
	}
	//********************
	public void caculate(){
		area = 2 * (length + width);
		perime = length * width;
	}
    //********************
	public void display(){
		System.out.printf("area = %d, perime = %d", area, perime);
	}
}
