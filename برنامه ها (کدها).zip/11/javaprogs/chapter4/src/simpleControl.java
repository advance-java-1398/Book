
public class simpleControl {
	   private double temperature;
	   //******************
	   public void setTemperature(double t)
	   {
	     temperature = t;
	   }
	   //******************
	   public double getTemperature()
	   {
	     return temperature;
	   }

}
