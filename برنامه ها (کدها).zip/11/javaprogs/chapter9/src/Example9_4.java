import java.util.*;                                    //Line 1
public class Example9_4
{
    static Scanner console = new Scanner(System.in);   //Line 4

    public static void main(String[] args)             //Line 5
    {                                                  //Line 6
        int dividend, divisor, quotient;               //Line 7

        try                                            //Line 8
        {                                              //Line 9
            System.out.print("Line 10: Enter the "
                           + "dividend: ");            //Line 10
            dividend = console.nextInt();              //Line 11
            System.out.println();                      //Line 12

            System.out.print("Line 13: Enter the "
                           + "divisor: ");             //Line 13
            divisor = console.nextInt();               //Line 14
            System.out.println();                      //Line 15

            quotient = dividend / divisor;             //Line 16
            System.out.println("Line 17: Quotient = "
                              + quotient);             //Line 17
        }                                              //Line 18
        catch (ArithmeticException aeRef)              //Line 19
        {                                              //Line 20
            System.out.println("Line 21: Exception  "
                              + aeRef.getMessage());   //Line 21
        }                                              //Line 22
        catch (InputMismatchException imeRef)          //Line 23
        {                                              //Line 24
            System.out.println("Line 25: Exception "
                               + imeRef);              //Line 25
        }                                              //Line 26
    } //end main                                       //Line 27
}
