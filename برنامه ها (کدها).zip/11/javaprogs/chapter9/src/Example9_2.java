import java.util.*;                                  //Line 1
public class Example9_2
{
    static Scanner console = new Scanner(System.in); //Line 4

    public static void main(String[] args)           //Line 5
    {                                                //Line 6
        int dividend, divisor, quotient;             //Line 7

        System.out.print("Line 8: Enter the "
                       + "dividend: ");              //Line 8
        dividend = console.nextInt();                //Line 9
        System.out.println();                        //Line 10

        System.out.print("Line 11: Enter the "
                       + "divisor: ");               //Line 11
        divisor = console.nextInt();                 //Line 12
        System.out.println();                        //Line 13

        if (divisor != 0)                            //Line 14
        {                                            //Line 15
            quotient = dividend / divisor;           //Line 16
            System.out.println("Line 17: "
                             + "Quotient = "
                             + quotient);            //Line 17
        }
        else                                         //Line 18
            System.out.println("Line 19: Cannot "
                             + "divide by zero.");   //Line 19
    } //end main                                     //Line 20
}
