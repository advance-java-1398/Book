import java.util.*;                                   //Line 1
public class Example9_9
{
    static Scanner console = new Scanner(System.in);  //Line 4

    public static void main(String[] args)            //Line 5
    {                                                 //Line 6
        double numerator;                             //Line 7
        double denominator;                           //Line 8

        try                                           //Line 9
        {                                             //Line 10
            System.out.print("Line 11: Enter the "
                           + "numerator: ");          //Line 11
            numerator = console.nextDouble();         //Line 12
            System.out.println();                     //Line 13

            System.out.print("Line 14: Enter the "
                           + "denominator: ");        //Line 14
            denominator = console.nextDouble();       //Line 15
            System.out.println();                     //Line 16

            if (denominator < 0.0000001)              //Line 17
               throw new MyDivisionByZeroException(); //Line 18

            System.out.println("Line 19: Quotient = "
                       + (numerator / denominator));  //Line 19
        }                                             //Line 20
        catch (MyDivisionByZeroException mdbze)       //Line 21
        {                                             //Line 22
            System.out.println("Line 23: " + mdbze);  //Line 23
        }                                             //Line 24
        catch (Exception e)                           //Line 25
        {                                             //Line 26
            System.out.println("Line 27: " + e);      //Line 27
        }                                             //Line 28
    } //end main                                      //Line 29
}
