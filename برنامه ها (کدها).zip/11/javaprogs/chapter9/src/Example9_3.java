import java.util.*;                                    //Line 1
public class Example9_3 
{
	   static Scanner console = new Scanner(System.in);       //Line 4

	   public static void main(String[] args)                 //Line 5
	   {                                                      //Line 6
	      int dividend, divisor, quotient;                    //Line 7

	      try                                                 //Line 8
	      {                                                   //Line 9
	         System.out.print("Line 10: Enter the "
	                        + "dividend: ");                  //Line 10
	         dividend = console.nextInt();                    //Line 11
	         System.out.println();                            //Line 12

	         System.out.print("Line 13: Enter the "
	                        + "divisor: ");                   //Line 13
	         divisor = console.nextInt();                     //Line 14
	         System.out.println();                            //Line 15

	         quotient = dividend / divisor;                   //Line 16
	         System.out.println("Line 17: Quotient = "
	                           + quotient);                   //Line 17
	      }                                                   //Line 18
	      catch (Exception eRef)                              //Line 19
	      {                                                   //Line 20
	         if (eRef instanceof ArithmeticException)         //Line 21
	             System.out.println("Line 22: Exception "
	                               + eRef);                   //Line 22
	         else if (eRef instanceof InputMismatchException) //Line 23
	             System.out.println("Line 24: Exception "
	                                + eRef );                 //Line 24
	      }//Line 25
	      finally
	      {
	    	  System.out.println("This output is in finally block.");
	      }
	      
	   } //end main                                           //Line 26
}
