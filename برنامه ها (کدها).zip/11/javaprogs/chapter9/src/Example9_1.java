import java.util.*;                                  //Line 1
public class Example9_1 
{
    static Scanner console = new Scanner(System.in); //Line 4

    public static void main(String[] args)           //Line 5
    {                                                //Line 6
        int dividend, divisor, quotient;             //Line 7

        System.out.print("Line 8: Enter the "
                       + "dividend: ");              //Line 8
        dividend = console.nextInt();                //Line 9
        System.out.println();                        //Line 10

        System.out.print("Line 11: Enter the "
                       + "divisor: ");               //Line 11
        divisor = console.nextInt();                 //Line 12
        System.out.println();                        //Line 13

        quotient = dividend / divisor;               //Line 14

        System.out.println("Line 15: Quotient = "
                         + quotient);                //Line 15
    } //end main                                     //Line 16
}
