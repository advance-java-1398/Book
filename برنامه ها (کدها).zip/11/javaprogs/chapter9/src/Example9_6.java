import java.util.*;                                  //Line 1
public class Example9_6 
{
    static Scanner console = new Scanner(System.in); //Line 4

    public static void main(String[] args)           //Line 5
    {                                                //Line 6
        int number;                                  //Line 7

        try                                          //Line 8
        {                                            //Line 9
            number = getNumber();                    //Line 10
            System.out.println("Line 11: number = "
                              + number);             //Line 11
        }                                            //Line 12
        catch (InputMismatchException imeRef)        //Line 13
        {                                            //Line 14
            System.out.println("Line 15: Exception "
                              + imeRef);             //Line 15
        }                                            //Line 16
    } //end main                                     //Line 17

    public static int getNumber()
                  throws InputMismatchException      //Line 18
    {                                                //Line 19
        int num;                                     //Line 20

        try                                          //Line 21
        {                                            //Line 22
            System.out.print("Line 23: Enter an "
                            + "integer: ");          //Line 23
            num = console.nextInt();                 //Line 24
            System.out.println();                    //Line 25

            return num;                              //Line 26
        }                                            //Line 27
        catch (InputMismatchException imeRef)        //Line 28
        {                                            //Line 29
            System.out.println("Line 30: Exception "
                              + imeRef);             //Line 30
            throw new InputMismatchException
                               ("getNumber");        //Line 31
        }                                            //Line 32
    } //end getNumber                                //Line 33
}
