import javax.swing.JFrame;
public class Example11_7 
{
   public static void main(String[] args)
   {
       TextFieldFrame textFieldFrame = new TextFieldFrame();
       textFieldFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
       textFieldFrame.setSize( 325, 150 ); // set frame size
       textFieldFrame.setVisible( true ); // display frame
   }
}
