import javax.swing.JFrame;
public class Example11_3
{
    private static final int WIDTH = 350;           
    private static final int HEIGHT = 100;          

    public static void main(String[] args)
    {
        LabelsColorsFonts demoObject = new LabelsColorsFonts();
        demoObject.setSize(WIDTH, HEIGHT);                             
        demoObject.setVisible(true);                                   
        demoObject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);            
    }
}
