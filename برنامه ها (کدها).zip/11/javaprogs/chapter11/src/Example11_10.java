import javax.swing.JFrame;
public class Example11_10
{
  public static void main( String args[] )
  {
    RadioButtonFrame radioButtonFrame = new RadioButtonFrame();
    radioButtonFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
    radioButtonFrame.setSize( 300, 150 ); // set frame size
    radioButtonFrame.setVisible( true ); // display frame
  } // end main
} // end class RadioButtonTest





