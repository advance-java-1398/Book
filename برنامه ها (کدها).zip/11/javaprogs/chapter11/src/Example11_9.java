import javax.swing.JFrame;
public class Example11_9
{
	 public static void main( String args[] )
	 {
	     CheckBoxFrame checkBoxFrame = new CheckBoxFrame();
	     checkBoxFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	     checkBoxFrame.setSize( 275, 100 ); // set frame size
	     checkBoxFrame.setVisible( true ); // display frame
	 } // end main
}


