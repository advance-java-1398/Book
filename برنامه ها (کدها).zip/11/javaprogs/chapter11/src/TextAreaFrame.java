import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JScrollPane;
public class TextAreaFrame extends JFrame
{
	public static final int  WIDTH = 300;
	public static final int  HEIGHT = 300;
	
	public TextAreaFrame()                                         //line 10 
	{                                                              //line 11
		setTitle("AreaText, JPanel, JScroolPanel");                //line 12
		setSize(WIDTH, HEIGHT);                                    //line 13
		final JTextField textField = new JTextField();             //line 14 
		final JPasswordField passwordField = new JPasswordField(); //line 15
		JPanel northPanel = new JPanel();                          //line 16
		northPanel.setLayout(new GridLayout(2, 2));                //line 15

		northPanel.add(new JLabel ("User name : ",
				SwingConstants.LEFT )); //line 17
		northPanel.add(textField);                               //line 18
		northPanel.add(new JLabel ("Password : ",
				SwingConstants.LEFT ));  //line 19
		northPanel.add(passwordField);                           //line 20
		add(northPanel, BorderLayout.NORTH);                     //line 21
		
		final JTextArea textArea = new JTextArea(8, 40);        //line 23
		
		JScrollPane scrollPane = new JScrollPane(textArea);     //line 25
		
		add(scrollPane, BorderLayout.CENTER);                   //line 28
		JPanel southPanel = new JPanel();                       //line 29
		JButton insertButton = new JButton("Insert");           //line 30
		southPanel.add(insertButton);                           //line 31
		add(southPanel,BorderLayout.SOUTH);                     //line 32
		insertButton.addActionListener(new ActionListener()    //line 33
		{
		public void actionPerformed(ActionEvent event)         //line 35
			{
			    textArea.append("User name : " +
			    		textField.getText() + ", "             //line 36
			    	+	" Password : " + new String
			    	(passwordField.getPassword()) + "\n");
			}                                                 //line 37
		});                                                   //line 38
	}                                                         //line 39
}                                                             //line 40
