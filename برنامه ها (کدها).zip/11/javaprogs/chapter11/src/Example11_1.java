import javax.swing.JOptionPane;                        //Line 1
public class Example11_1 
{
	public static void main(String[] args)
	{
        double radius;                                 //Line 6
        double area;                                   //Line 7
        double circumference;                          //Line 8

        String radiusString;                           //Line 9
        String outputStr;                              //Line 10

        radiusString =
                    JOptionPane.showInputDialog
                    ("Enter the radius: ");            //Line 11

        radius = Double.parseDouble(radiusString);     //Line 12

        area = Math.PI * radius * radius;              //Line 13
        circumference = 2 * Math.PI * radius;          //Line 14
        outputStr = "Radius: " + radius + "\n" +
                    "Area: " + area + " square units\n" +
                    "Circumference: " + circumference +
                    " units";                          //Line 15

        JOptionPane.showMessageDialog(null, outputStr,
                                    "Circle",
                   JOptionPane.INFORMATION_MESSAGE);   //Line 16

        System.exit(0);                                //Line 17
    }                                                  //Line 18
}
