import javax.swing.JFrame;

public class Example11_15
{
  public static void main( String args[] )
  {
    MouseDetails mouseFrame = new MouseDetails();
    mouseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mouseFrame.setSize( 400, 150 ); // set frame size
    mouseFrame.setVisible( true ); // display frame
   } // end main
} 





