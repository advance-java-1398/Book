import javax.swing.JFrame;
public class Example11_13
{
   public static void main( String args[] )
   {
     MouseFrame mouseTrackerFrame = new MouseFrame();
     mouseTrackerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
     mouseTrackerFrame.setSize( 300, 100 ); // set frame size
     mouseTrackerFrame.setVisible( true ); // display frame
   } // end main
} 



