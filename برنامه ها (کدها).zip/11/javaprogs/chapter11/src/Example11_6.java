import javax.swing.JFrame;
public class Example11_6 
{
   private static final int WIDTH = 325;
   private static final int HEIGHT = 150;
   public static void main(String[] args)
   {
       CircleProgram cirObject = new CircleProgram();
	   cirObject.setSize(WIDTH, HEIGHT);
	   cirObject.setVisible(true);
	   cirObject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}
