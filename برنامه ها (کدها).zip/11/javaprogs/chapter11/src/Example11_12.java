import javax.swing.JFrame;

public class Example11_12
{
  public static void main( String args[] )
  {
      JListFrame jFrame =
      new JListFrame();
      jFrame.setDefaultCloseOperation(
      JFrame.EXIT_ON_CLOSE );
      jFrame.setSize( 350, 140 ); // set frame size
      jFrame.setVisible( true ); // display frame
   } // end main
}


