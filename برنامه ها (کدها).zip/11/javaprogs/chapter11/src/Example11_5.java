import javax.swing.JFrame;
public class Example11_5
{
      public static void main( String args[] )
      {
         BorderLayoutFrame borderLayoutFrame = new BorderLayoutFrame();
         borderLayoutFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
         borderLayoutFrame.setSize( 300, 200 ); // set frame size
         borderLayoutFrame.setVisible( true ); // display frame
     } // end main
} // end class Example11_5




