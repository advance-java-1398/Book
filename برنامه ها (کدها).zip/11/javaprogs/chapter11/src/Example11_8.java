import javax.swing.JFrame;
public class Example11_8 
{
    public static void main(String[] args)
    {
    	TextAreaFrame t = new TextAreaFrame();
    	t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   t.setVisible(true);

    }
}
