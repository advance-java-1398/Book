import javax.swing.JFrame;

public class Example11_11
{
  public static void main(String[] args)
  {
	ComboBoxFrame  comboFrame1 = new ComboBoxFrame();
	comboFrame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	comboFrame1.setVisible(true);
  }
}
