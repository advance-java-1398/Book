import javax.swing.JFrame;

public class Example11_14
{
   public static void main( String args[] )
   {
       KeyFrame keyDemoFrame = new KeyFrame();
       keyDemoFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
       keyDemoFrame.setSize( 350, 100 ); // set frame size
       keyDemoFrame.setVisible( true ); // display frame
   } // end main
} // end class KeyDemo






