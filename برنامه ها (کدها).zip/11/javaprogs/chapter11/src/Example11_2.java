import javax.swing.*;
public class Example11_2
{
	  public static void main(String[] args)
	  {
	    JFrame frame = new JFrame();
	    final int width = 300, height = 100;
	    frame.setSize(width, height);
	    frame.setTitle("Empty Frame");
	    frame.setVisible(true);
	  }
}
