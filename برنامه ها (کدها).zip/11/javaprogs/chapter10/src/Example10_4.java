import java.io.*;
import java.util.*;
public class Example10_4 
{
	public static void main(String[] args)
	{
		String fileName = "nameSt.dat";
		createFile(fileName);
		printFile(fileName);
	}
	//**************
	public static void createFile(String fileName)
	{
		Scanner console = new Scanner(System.in);
		try
		{
			PrintWriter outFile = new PrintWriter(fileName);  //line 16
			String str;                                       //line 17
			double grade;                                     //line 18
			System.out.print("Enter a name : ");              //line 19
			str = console.next();                             //line 20
			while(!str.trim().equals("stop"))                 //line 21
			{                                  
				outFile.print(str + " ");                     //line 23
				System.out.print("Enter grade :");
				grade = console.nextDouble();
				outFile.print(grade);                         //line 26
				outFile.print(" ");                           //line 27
				System.out.print("Enter a name : ");
				str = console.next();
			}                                                 //line 30
			outFile.close();                                  //line 31
		}
        
		catch(Exception e) 
        {
        	System.out.print(e.getMessage());
        }
	}//end of createFile
    //*****************
	public static void printFile(String fileName)
	{
		try
		{
			Scanner inFile = new Scanner(new FileReader(fileName)); //line 44
			String str;
			double grade;
			System.out.print("\nRead from file : \n");
			str = inFile.next();                                    //line 48
			while(str != null)                                      //line 49
			{
				grade = inFile.nextDouble();
				System.out.printf("%s : %5.2f", str, grade);        //line 52 
				System.out.println();
				str = inFile.next();
			}                                                       //line 55
			inFile.close();
		}

		catch(Exception e)
		{
			if(e.getMessage() != null)
			{
				System.out.print(e.getMessage());
			}
		}
	}
}
