import java.io.*;
import java.util.*;
public class Example10_6
{    
	   static Scanner console = new Scanner(System.in);
	   public static void main(String[] args) throws Exception
	   {
         String fileName = "comTel.dat";
		 PrintWriter outFile = new PrintWriter(fileName);
	     BufferedWriter writer = new BufferedWriter(outFile);
	     String str;
	     System.out.print("Enter name and tel : ");
	     str = console.nextLine();
	     while(!str.trim().equals("stop"))
	     {
	       writer.write(str + "\n");
	       System.out.print("Enter name and tel : ");
	       str = console.nextLine();
	     }
	     //*************************
	     writer.flush();
	     writer.close();
	     FileReader inFile = new FileReader(fileName);
	     LineNumberReader  reader = new LineNumberReader(inFile);
	     System.out.println("\n Read from file :");
	     str =  reader.readLine();
	     while(str != null)
	     {
	        System.out.print(reader.getLineNumber());
            System.out.print(", ");
	        System.out.println(str);
	        str =  reader.readLine();
	     }
	     reader.close();
	   }
}
