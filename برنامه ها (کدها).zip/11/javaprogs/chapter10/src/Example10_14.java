import java.io.*;
import java.util.*;
public class Example10_14
{
	static Scanner console = new Scanner(System.in);
	public static void main(String[] args) throws Exception           //line 6
	{
		String fileName = "seqfile.dat";
		writeData(fileName);
		System.out.println("\nContent of file before edition :");
		printData(fileName);
		editData(fileName);
		System.out.println("\nContent of file after edition :");
		printData(fileName);
	}                                                                 //line 15
	//**********************
	public static void writeData(String outputFile) throws Exception  //line 17
	{
		PrintWriter  outFile = new PrintWriter(outputFile);
		String name;
		int stNo;
		double grade;
		System.out.print("Enter a name : ");
	    name = console.next();
	    while(!name.trim().equals("stop"))
	    {
	    	System.out.print("Enter student number and grade : ");
	    	stNo = console.nextInt();
	    	grade = console.nextDouble();
	    	outFile.print(name + " ");
	    	outFile.print(stNo + " ");
	    	outFile.print(grade + " ");
			System.out.print("Enter a name : ");
			name = console.next();
	    }
	    outFile.close();
	}//end of writeData                                                 //line 37
	//*************************
	public static void editData(String inputFile) throws Exception      //line 39
	{
		Scanner inFile = new Scanner(new FileReader(inputFile));        //line 41
		PrintWriter outFile = new PrintWriter("help.dat");              //line 42
		int searchStNo;
		double newGrade;
		String name;
		int stNo;
		double grade;
		System.out.print("Enter stNo to search : ");
		searchStNo = console.nextInt();                                  //line 49
		System.out.print("Enter new grade : ");                          //line 50 
		newGrade = console.nextDouble();                                 //line 51
		name = inFile.next();                                            //line 52
		while(true)                                                      //line 53
		{
			stNo = inFile.nextInt();                                     //line 55
			grade = inFile.nextDouble();                                 //line 56
			if(stNo == searchStNo)                                       //line 57
			{
		      grade = newGrade;		
			}
			outFile.print(name + " ");                                   //line 61
			outFile.print(stNo + " ");                                   //line 62
			outFile.print(grade + " ");                                  //line 63
			if(!inFile.hasNext())                                        //line 64
		        break;		
			name = inFile.next();
		}//end of while                                                   //line 67      
		outFile.close();                                                  //line 68
		inFile.close();                                                   //line 69
		File f = new File("seqfile.dat");                                 //line 70
		File hf = new File("help.dat");                                   //line 71
        f.delete();                                                       //line 72
		hf.renameTo(f);                                                   //line 73
	}                                                                     //line 74
	//**********************
	public static void printData(String file) throws Exception            //line 76
	{
		String name;
		int stNo;
		double grade;
		Scanner inFile = new Scanner(new FileReader(file));
		while(true)                                                        //line 82
		{
			if (inFile.hasNext())                                          //line 84
			{
				name = inFile.next();
				stNo = inFile.nextInt();
				grade = inFile.nextDouble();
                System.out.println(name + ", " + stNo + ", " + grade);
			}
			else
				break;
		}                                                                   //line 93
		System.out.println();
		inFile.close();
	} //end of printData                                                    //line 96
}
