import java.io.*;
public class Example10_3 
{
	   public static void main(String[] args)
	   {
	      String filename = "first.txt";
	      processInputFile(filename);
	    }
	    //***
	    private static void processInputFile(String filename)
	    {
	      try
	      {
	         FileReader inFile = new FileReader(filename);
	         int nextChar;
	         nextChar =  inFile.read();
	         while(nextChar != -1)
	         {
	            System.out.println((char)nextChar);
	            nextChar =  inFile.read();
	         }
	         inFile.close();
	      }
	      catch(FileNotFoundException e)
	      {
	         System.out.println("Unable to open " + filename);
	      }
	      catch(IOException e)
	      {
	         System.out.println("Unable to close " + filename);
	      }
	   }//end of processInputFile
}
