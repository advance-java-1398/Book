import java.io.*;
import java.util.*;
public class Example10_12
{
	static Scanner console = new Scanner(System.in);
    public static void main(String[] args)  throws Exception
    {
            // The name of the binary file to be written/read.
            final String datafile = "data.bin";
            writeData(datafile);
            readData(datafile);
    }
    // Write a string, and an array of doubles to the given file.
    public static void writeData(String file) throws Exception
    {
        DataOutputStream out = null;
        String name ;
        double[] grades;
        int num ; //number of grades
        out = new DataOutputStream(new FileOutputStream(file));
        System.out.print("Enter name : ");
        name = console.next();
        while(!name.trim().equals("stop"))
        {
               out.writeUTF(name);
               System.out.print("Enter number of courses : ");
               num = console.nextInt();
               out.writeInt(num);
               grades = new double[num];
               for(int i = 0; i < num; i++)
               {
            	  System.out.print("Enter grade " + (i + 1) + " : ");
                  grades[i] = console.nextDouble();
                  out.writeDouble(grades[i]);
               }
               System.out.print("Enter name : ");
               name = console.next();
        }//while
    }//end of writeData
    // Read a string, and an array of doubles from the given file.
    public static void readData(String file) throws Exception
    {
    	try
    	{
            DataInputStream in = null;
            in = new DataInputStream(new FileInputStream(file));
            System.out.println("\nThe contents of file is :");
            int num;
            String name;
            name = in.readUTF().trim();
            while(name != null)
            {
                   System.out.print(name + " : ");
                   num = in.readInt();
                   for(int i = 0; i < num; i++)
                   {
                        System.out.print(in.readDouble() + ", ");
                   }
                    System.out.println();
                    name = in.readUTF().trim();
            }//while
    	}
    	catch(Exception e)
    	{
    		if (e.getMessage() != null)
    		{
    	    	System.out.print(e.getMessage());
    		}
    	}
    }//end of readData
}
