import java.io.*;
public class Example10_2
{
	   public static void main(String[] args)
	   {
	      String filename = "first.txt";
	      processOutputFile(filename);
	    }
	    //***
	    private static void processOutputFile(String filename)
	    {
	      try
	      {
	         FileWriter outFile = new FileWriter(filename);
	         int nextChar;
	         System.out.print("Enter first character:");
	         nextChar =  System.in.read();
	         while(nextChar != -1)
	         {
	            outFile.write(nextChar);
	            System.in.read(); System.in.read();//discard Enter key
	            System.out.print("Enter next character:");
	            nextChar =  System.in.read();
	         }
	         outFile.close();
	      }
	      catch(FileNotFoundException e)
	      {
	         System.out.println("Unable to open "+ filename);
	      }
	      catch(IOException e)
	      {
	         System.out.println("Unable to close "+filename);
	      }
	   }//end of processOutputFile
}
