import java.util.*;
import java.io.*;
public class Example10_1 
{
	   static Scanner in = new Scanner(System.in);
	   public static void main(String[] args) throws Exception
	   {
	      String fileName;
	      System.out.print("Enter file name : ");
	      fileName = in.next();
	      File f = new File(fileName);
	      File dir = new File("folder");

	      if(f.exists())
	      {
	          System.out.println(f.getName() + " exists.");
	          System.out.println("The length of file is " + f.length()+" byes.");
	          if(f.canRead())
	              System.out.println("OK to read.");
	          if(f.canWrite())
	              System.out.println("OK to write.");
	      }
	      else
	         System.out.println("File <" + f.getName() + "> does not exist.");
	      if(dir.mkdir())
	          System.out.println("direcory <" + dir.getName() + "> created.");
	      else  if(dir.exists())
	          System.out.println("direcory <" + dir.getName() + "> already exist.");
	      if(f.isFile())
	          System.out.println("<" + f.getName() + "> is a file.");
	      if(dir.isDirectory())
	          System.out.println("<" + dir.getName()+ "> is a directory.");
	      System.out.println("the absolute Path of <" + f.getName()+"> is " +
	                                                f.getAbsolutePath());
	      System.out.println("the canonical path of <" + f.getName() + "> is "+
	                                                f.getCanonicalPath());
	      System.out.println("the parent directory of <" + dir.getName() + "> is " +
	                                                dir.getParent());
	      if(f.isHidden())
	           System.out.println("the file <" + f.getName() + "> is hidden.");
	      else
	           System.out.println("the file <" + f.getName() + "> is not hidden.");
	      String dirname =  f.getAbsolutePath();
	      File f1 = new File("f:/javaprogs/chapter10");
	      if(f1.isDirectory())
	      {
	         System.out.println("directory of " + dirname);
	         String s[] = f1.list();
	         for(int i = 0; i < s.length; i++)
	              System.out.println("\t" + s[i]);
	       }
	   }
}
