import java.io.*;
import java.util.*;
public class Example10_15
{
	   static Scanner console = new Scanner(System.in);
	   final static int SIZE = 2;
	   private static StudentClass[] ob = new StudentClass[SIZE];
	   public static void main(String[] args) throws Exception
	   {
	      while(true)
	      {
	         switch(menu())
	         {
	            case 1:
	                 enter();
	                 break;
	            case 2:
	                 report();
	                 break;
	            case 3:
	                 search();
	                 break;
	            case 4:
	                 save();
	                 break;
	            case 5:
	                 restore();
	                 break;
	            case 6:
	                System.exit(0);
	         }//end of switch
	      } //end of while
	   }//end of main()
	   //***
	   static int menu() throws Exception
	   {
	     int c;
	     System.out.println("1.Enter data in array.");
	     System.out.println("2.Report data from file.");
	     System.out.println("3.Search a student.");
	     System.out.println("4.Save data in file.");
	     System.out.println("5.Restore data from file.");
	     System.out.println("6.Exit.");
	     System.out.print("Enter your select(1-6):");
	     c = console.nextInt();
	     return c;
	   }
	   //***
	   static void enter() throws Exception, IOException
	   {
		   String stName;
		   int stId, stUnit;
		   float stAve;
	       for(int i = 0; i < SIZE; i++)
	       {
	          ob[i] = new StudentClass();
	          System.out.print("Enter name:");
	          stName = console.next();
	          ob[i].setName(stName);
	          System.out.print("Enter id:");
               stId = console.nextInt();
	          ob[i].setId(stId); 
	          System.out.print("Enter ave:");
              stAve = console.nextFloat();
	          ob[i].setAve(stAve); 
	          System.out.print("Enter units:");
	          stUnit = console.nextInt();
	          ob[i].setUnit(stUnit); 
	       }//end of for
	   }
	   //***
	   static void report() throws EOFException, IOException, ClassNotFoundException
	   {
	      FileInputStream f1 = new FileInputStream("ob.txt");
	      ObjectInputStream inFile = new ObjectInputStream(f1);
	      StudentClass ob1 = new StudentClass();
	      try {
	           for(int i = 0; i < SIZE; i++)
	           {
	                int c;
	                ob1 = (StudentClass) inFile.readObject();
	                System.out.println("name = " + ob1.getName());
	                System.out.println("id = " + ob1.getId());
	                System.out.println("ave = " + ob1.getAve());
	                System.out.println("unit = " + ob1.getUnit());
	           }//end of for
	       }//end of try
	       catch(EOFException e)
	       {
	          System.out.println("error");
	          inFile.close();
	       } //end of catch
	       catch(ClassNotFoundException e)
	       {
	          System.out.println("class error");
	       }
	   }//end of report
	   //***
	   static void save() throws Exception, IOException
	   {
	       FileOutputStream f = new FileOutputStream("ob.txt");
	       ObjectOutputStream outFile = new ObjectOutputStream(f);
	       for(int i = 0; i < SIZE; i++)
	       {
	          outFile.writeObject(ob[i]);
	          outFile.flush();
	       }
	       outFile.close();
	   }
	   //***
	   static void search() throws Exception, IOException
	   {
	     int num;
	     System.out.print("Enter student number to search:");
	     num = console.nextInt();
	     int i;
	     for(i = 0; i < SIZE; i++)
	     {
	        if(num == ob[i].getId())
	            break;
	     }
	     if(i < SIZE)
	        System.out.println("Favourite student exist.");
	     else
	        System.out.println("Favourite student not exist.");
	   }
	   //***
	   static void restore() throws EOFException, IOException, ClassNotFoundException
	   {
	      FileInputStream f1 = new FileInputStream("ob.txt");
	      ObjectInputStream inFile = new ObjectInputStream(f1);
	      for(int i = 0; i < SIZE; i++)
	      {
	         ob[i] = (StudentClass) inFile.readObject();
	      }
	      inFile.close();
	   }
}
