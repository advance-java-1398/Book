import java.io.*;
import java.util.*;
public class Example10_5
{
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) throws Exception
	{
       String fileName = "student.dat";                    //line 8
	   PrintWriter outFile  = new PrintWriter(fileName);   //line 9
	   BufferedWriter writer = new BufferedWriter(outFile);//line 10
	   String str;
	   System.out.print("Enter a name :");
	   str = in.nextLine();                                //line 13
	   while(!str.trim().equals("stop"))                   //line 14
	   {
	     writer.write(str + "\n");                         //line 16
	     System.out.print("Enter a name :");
	     str = in.nextLine();
	   }                                                   //line 19
	   //****************
	   writer.flush();                                     //line 21
	   writer.close();
	   FileReader inFile = new FileReader(fileName);       //line 23
	   BufferedReader reader = new BufferedReader(inFile); //line 24
	   System.out.println("\nRead from file :");
	   str =  reader.readLine();                           //line 26
	   while(str != null)                                  //line 27
	   {
	      System.out.println(str);
	      str =  reader.readLine();
	   }                                                   //line 31
	   reader.close();
	}
}
