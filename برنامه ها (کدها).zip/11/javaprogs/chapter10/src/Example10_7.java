import java.io.*;
public class Example10_7
{
	  public static void main(String[] args) throws IOException
	  {
	    String tmp = "abcdefghijklmniopqrstuvwxyz";
	    int len = tmp.length();
	    char[] c = new char[len];
	    tmp.getChars(0, len, c, 0);
	    // *** class CharArrayReader
	    CharArrayReader in1 = new CharArrayReader(c);
	    CharArrayReader in2 = new CharArrayReader(c, 0, 5);
	    int i;
	    System.out.println("Test CharArrayReader:");
	    System.out.println("in1 is:");
	    while((i = in1.read()) != -1)
	        System.out.print((char) i);
	    System.out.println();
	    System.out.println("in2 is:");
	    while((i = in2.read()) != -1)
	        System.out.print((char) i);
	    System.out.println();
	    // *** class CharArrayWriter
	    CharArrayWriter f = new CharArrayWriter();
	    String s = "This should end up in the array.";
	    char[] buf = new char[s.length()];
	    s.getChars(0, s.length(), buf, 0);
	    f.write(buf);
	    System.out.println("Test CharArrayWriter:");
	    System.out.println("Buffer as a string.");
	    System.out.println(f.toString());
	    System.out.println("Into array");
	    char[] ar = f.toCharArray();
	    for(i = 0; i < ar.length; i++)
	       System.out.print(ar[i]);
	    System.out.println("\nTo a FileWriter().");
	    FileWriter f2 = new FileWriter("test.txt");
	    f.writeTo(f2);
	    f2.close();
	    System.out.println("Doing a reset.");
	    f.reset();
	    for(i = 0; i < 3; i++)
	      f.write('X');
	    System.out.println(f.toString());
	  }
}
