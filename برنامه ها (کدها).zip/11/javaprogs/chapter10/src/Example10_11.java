import java.io.*;
import java.util.*;
public class Example10_11 
{
	 static Scanner console = new Scanner(System.in);
	 public static void main(String[] args) throws Exception
	 {
		 String fileName = "test.txt";   
	     FileOutputStream outFile = new FileOutputStream(fileName);
	     OutputStream outStream  = new BufferedOutputStream(outFile);
	     String str ;
	     System.out.print("Enter a string:");
	     str = console.nextLine();
	     while(!str.trim().equals("stop"))
	     {
	        byte[] b = str.getBytes();
	        outStream.write(b);
	        outStream.write('\n');
	        System.out.print("Enter a string:");
	        str = console.nextLine();
	     }
	     outStream.flush();
	     outStream.close();
	     FileInputStream inFile = new FileInputStream(fileName);
	     InputStream inStream = new BufferedInputStream(inFile);
	     int size = inStream.available();
	     byte[] c = new byte[size];
	     inStream.read(c);
	     System.out.println("The contents of file is : \n");
	     System.out.println( new String(c, 0, size));
	     inStream.close();
	   }
}
