import java.io.*;
import java.util.*;
public class Example10_9
{
	  static Scanner console = new Scanner(System.in);
	  public static void main(String[] args) throws Exception
	  {
	    String str;
	    String fileName = "file1.dat";
	    byte[] buf;
	    OutputStream outFile = new FileOutputStream(fileName);
	    System.out.print("Enter a string : ");
	    str = console.nextLine();
	    while(!str.trim().equals("stop"))
	    {
	      buf = str.getBytes();
	      outFile.write(buf);
	      outFile.write('\n');
	      System.out.print("Enter a string : ");
	      str = console.nextLine();
	    }
	    outFile.close();
	  }

}
