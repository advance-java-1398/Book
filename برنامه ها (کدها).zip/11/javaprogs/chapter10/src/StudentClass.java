import java.io.*;
public class StudentClass implements Serializable 
{
	   private String name;
	   private int id ;
	   private float ave;
	   private int unit;
	   public String getName()
	   {
		   return name;
	   }
	   
	   public int getId()
	   {
		   return id;
	   }
	   public float getAve()
	   {
		   return ave;
	   }
	   public int getUnit()
	   {
		   return unit;
	   }
	   public void setName(String stName)
	   {
		    name = stName;
	   }
	   
	   public void setId(int stId)
	   {
		   id = stId;
	   }
	   public void setAve(float stAve)
	   {
		    ave = stAve;
	   }
	   public void setUnit(int stUnit)
	   {
		   unit = stUnit;
	   }
}
