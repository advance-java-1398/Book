import java.io.*;
import java.util.*;
public class Example10_16
{
	static Scanner console = new Scanner(System.in);
	final static int len = 36;
	public static void main(String[] args) throws Exception
	{
		try
		{
           String fileName = "random.dat";
	       RandomAccessFile f = new RandomAccessFile(fileName, "rw");
	       String name;
	       int stNo;
	       float grade;
	       System.out.print("Enter a name : ");
	       name = console.next();
	       while(!name.trim().equals("stop"))
	       {
	          System.out.print("Enter student number , grade:");
	          stNo = console.nextInt();
	          grade = console.nextFloat();
	          f.seek((stNo - 100) * len);
	          f.writeUTF(name + " ");
	          f.writeFloat(grade);
	          f.writeUTF(" ");
              System.out.print("Enter a name : ");
		      name = console.next();
	       }//end of while
	       System.out.print("Enter stNo to search:");
	       stNo = console.nextInt();
	       f.seek(len * (stNo - 100));
	       name = f.readUTF();
	       grade = f.readFloat();
	       System.out.println("Student and grade are : " + name + "," + grade );
	       f.close();
	    }//end of try
		catch(Exception e)
		{
			System.out.print(e.getMessage());
		}
	}//end of main
}
