import java.io.*;
public class Example10_10
{
	   public static void main(String[] args) throws Exception
	   {
	      String tmp = "abcdefghijklmnopqrstuvwxyz";
	      byte[] b = tmp.getBytes();
	      ByteArrayInputStream in1 = new ByteArrayInputStream(b);
	      ByteArrayInputStream in2 = new ByteArrayInputStream(b, 0, 3);
	      int i;
	      System.out.println("in1 is:");
	      while((i = in1.read()) != -1)
	        System.out.print((char) i);
	      System.out.println("\nin2 is:");
	      while((i = in2.read()) != -1)
	          System.out.print((char) i);
	      in2.reset();
	      System.out.println("\nin2  after reset is:");
	      while((i = in2.read()) != -1)
	          System.out.print(Character.toUpperCase((char) i));
	      //*** test ByteArrayOutputStream
	      ByteArrayOutputStream f = new ByteArrayOutputStream();
	      String s = "This should end up in the array.";
	      byte[] buf = s.getBytes();
	      f.write(buf);
	      System.out.println("\nBuffer as a string:");
	      System.out.println(f.toString());
	      System.out.println("Into array:");
	      byte[] b1 = f.toByteArray();
	      for(int j = 0; j < b1.length; j++)
	         System.out.print((char) b1[j]);
	      System.out.println("\nTo an OutputStream()");
	      OutputStream f2 = new FileOutputStream("test.txt");
	      f.writeTo(f2);
	      f2.close();
	      System.out.println("Doing a reset.");
	      f.reset();
	      for(int j = 0; j < 3; j++)
	         f.write('X');
	      System.out.println(f.toString());
	    }
}
