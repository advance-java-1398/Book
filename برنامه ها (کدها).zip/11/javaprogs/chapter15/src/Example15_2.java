import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class Example15_2
{
  public static void main( String[] args ) //line 6 
  {
   // create and name each runnable             
   PrintTask task1 = new PrintTask( "thread1" ); //line 9
   PrintTask task2 = new PrintTask( "thread2" );
   PrintTask task3 = new PrintTask( "thread3" ); //line 11

   System.out.println( "Starting threads" );
   // create ExecutorService to manage threads                        
   ExecutorService threadExecutor =              //line 15
	         Executors.newFixedThreadPool(3);
   // start threads and place in runnable state   
   threadExecutor.execute( task1 ); // start task1 //line 18
   threadExecutor.execute( task2 ); // start task2
   threadExecutor.execute( task3 ); // start task3 //line 20
   threadExecutor.shutdown(); // shutdown worker threads
   System.out.println( "Threads started, main ends\n" );
  } // end main     //line 23
}




