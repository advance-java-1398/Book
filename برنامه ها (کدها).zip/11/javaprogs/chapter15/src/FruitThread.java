class FruitThread extends Thread
{
   private String fruit = "Fruit";
   private int times = 0;
   FruitThread(String name, int execution)
   {
      fruit = name;
      times = execution;
   }
   //***********
   public void run()
   {
       for(int i = 0; i < times; i++)
       {
          System.out.println(fruit + i);
          yield();
       }
   }
}

