public class Example15_3
{
  public static void main(String[] args)
  {
    FruitThread apple = new FruitThread("Apple", 5);
    FruitThread orange = new FruitThread("Orange", 5);
    apple.start();
    orange.start();
  }
}
