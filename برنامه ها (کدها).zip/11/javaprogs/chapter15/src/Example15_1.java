
public class Example15_1 
{
   public static void main(String[] args)
   {
     AppleThred   apple  = new AppleThred();
     OrangeThread orange = new OrangeThread();
     apple.start();
     orange.start();
    }
}
