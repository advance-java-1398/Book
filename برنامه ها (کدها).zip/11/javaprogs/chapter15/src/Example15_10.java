import javax.swing.JFrame;
public class Example15_10
{
  public static void main( String args[] )
  {
   // create new RandomCharacters object
   RandomCharacters ap = new RandomCharacters();
   // set application to end when window is closed
   ap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
  } // end main
}
