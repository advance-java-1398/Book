import javax.swing.*;
//Shows an animated bouncing ball.
public class Example15_4
{
  public static void main(String[] args)
  {
    BounceFrame frame = new BounceFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
}
 
 


