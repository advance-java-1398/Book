public interface Buffer
{
// place int value into Buffer	
   public void set( int value ); 
   public int get(); // return int value from Buffer
}




