import javax.swing.JFrame;
public class Example13_7
{
  public static void main(String[] args)
  {
    DesktopFrame frame = new DesktopFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
}
