
public class Example13_6
{
  public static void main(String[] args)
  {
    SimpleTree treeFrame = new SimpleTree();
    treeFrame.setSize(275, 300);
    treeFrame.setVisible(true);
  }
}
