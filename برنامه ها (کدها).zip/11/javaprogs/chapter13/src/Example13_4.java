import javax.swing.JFrame;

public class Example13_4
{
  public static void main( String args[] )
  {
    PopupFrame popupFrame = new PopupFrame(); 
    popupFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    popupFrame.setSize( 300, 200 ); // set frame size
    popupFrame.setVisible( true ); // display frame
  } // end main
}

