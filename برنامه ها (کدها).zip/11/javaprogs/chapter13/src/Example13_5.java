import javax.swing.JFrame;
public class Example13_5
{
  public static void main(String[] args)
  {
    TableFrame frame = new TableFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setTitle("Sample table");
    frame.setSize(450, 250);
    frame.setVisible(true);
   }
}
