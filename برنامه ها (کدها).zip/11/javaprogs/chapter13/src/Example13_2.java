import javax.swing.JFrame;
public class Example13_2
{
   public static void main(String args[])
   {
      TextEditor texted = new TextEditor();
      texted.setSize(300, 150);
      texted.setVisible(true);
      texted.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
}
