import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TableFrame extends JFrame
{
   private String[] columnNames =                    //line 6 
       {"Title", "Code", "Author", "Page", "Price" };

   private Object[][] cells =                        //line 9
   {
      { "C programming", 110, "Ghomi", 600, 9000 },
      { "Java Programming", 220, "Ghomi", 500, 8000 },
      { "Computer Networks", 330,"Tanenbaum", 700, 10000 },
      { "Circuit analysis", 250,"Hait", 480, 7000 },
      { "Data communication", 360, "Stallings", 800, 12000 },
      { "Image proccesing", 400, "Gonzales", 850, 12000 },
      { "C# programming", 500, "Ghomi", 600, 10000 },
      { "Computer Organization", 650, "Stallings", 750, 11000},
      { "Data structures", 550, "Gjomi", 380, 8000 }
   };

   public TableFrame()                               //line 22
   {
      final JTable table = new JTable(cells, columnNames); //line 24
      add(new JScrollPane(table), BorderLayout.CENTER);    //line 25
      JButton printButton = new JButton("Print");          //line 26
      printButton.addActionListener(new                    //line 27
         ActionListener()
         {
            public void actionPerformed(ActionEvent event)
            {
               try
               {
                  table.print();
               }
               catch (java.awt.print.PrinterException e)
               {
                  e.printStackTrace();
               }
            }
         });                                              //line 41
      JPanel buttonPanel = new JPanel();                  //line 42
      buttonPanel.add(printButton);                       //line 43
      add(buttonPanel, BorderLayout.SOUTH);               //line 44
    }                                                     //line 45
}                                                         //line 46




