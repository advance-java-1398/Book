import javax.swing.JFrame;

public class Example13_8
{
  public static void main(String args[])
  {
    TextEditor2 textEdit = new TextEditor2();
    textEdit.setSize(300, 150);
    textEdit.setVisible(true);
    textEdit.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
}
