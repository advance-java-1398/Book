
public class Example2_5 {
	public static void main(String[] args){
		int x = 200;
		System.out.printf("\n %%5x = %d\n", x * 5 /100);
        System.out.printf("\n\"each\"\t\"word\"\t\"is\"\n");
        System.out.printf("\n\"tabed\"\t\"over\"\t\"once\"");
	}

}
