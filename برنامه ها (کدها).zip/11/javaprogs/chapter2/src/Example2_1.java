
public class Example2_1 {
   public static void main(String[] args)
   {
	   System.out.print("Java is a good language ");
	   System.out.println("and it is my favorite.");
	   System.out.println("This is my first program in Java.");
	   System.out.println("I wrote it in Eclipse.");
   
   }
}
