
public class Example2_6 {
	public static void main(String[] args){
		int x = 125, y = 1468;
		float m = 327.348f, n = 4351.32f;
		System.out.printf("x = %5d, y = %3d\n", x, y);
		System.out.printf("m = %7.2f , n = %6.2f\n", m, n);
        System.out.printf("%5s %5d", "This is program No.", 6);
	}

}
