
public class Example2_3 {
   public static void main(String[] args){
	   System.out.print("Line 1 : 29 / 4 = " + (29 / 4) + "\n");
	   System.out.print("Line 2 : 29 + 4 = " + 29 + 4 + "\n");
	   System.out.println("Line 3 :Computer science");
	   System.out.println("Line 4 : " + 'A');
	   System.out.println("Line 5 : " + 2 + 3 * 5);
	   System.out.println("Line 6 : " + "Computer \n\t Science");
   }   

}
