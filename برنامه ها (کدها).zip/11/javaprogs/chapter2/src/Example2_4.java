
public class Example2_4 {
	public static void main(String[] args){
		int x = 153;
		double y = 1594.678;
		float m =12.6f;
		System.out.printf("This is a test. ");
		System.out.printf("This is another test.\n");
		System.out.printf("This is third test.");
		System.out.printf("\nx = %d, y = %f, m =%f ", x, y, m);
		System.out.printf("\ny = %e, m = %e ", y, m);
	}  

}
