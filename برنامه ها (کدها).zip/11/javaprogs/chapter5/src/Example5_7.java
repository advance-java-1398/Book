import static java.lang.Character.*;
public class Example5_7 {
    public static void main(String[] args)
    {
    	System.out.println("Uppercase('a') = " + toUpperCase('a'));
    	System.out.println("isLetter('a') = " + isLetter('a'));
    	System.out.println("isLetter('*') = " + isLetter('*'));
    	System.out.println("isUpperCase('b') = " + isUpperCase('b'));
    	System.out.println("isSpaceChar(' ') = " + isSpaceChar(' '));
    }
}
